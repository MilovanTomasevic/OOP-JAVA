package sa_radio_dugmadima;

public enum Oznaka {
	TEL, TAB
}
