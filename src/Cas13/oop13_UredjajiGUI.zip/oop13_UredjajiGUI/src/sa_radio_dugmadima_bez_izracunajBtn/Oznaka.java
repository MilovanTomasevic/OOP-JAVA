package sa_radio_dugmadima_bez_izracunajBtn;

public enum Oznaka {
	TEL, TAB
}
