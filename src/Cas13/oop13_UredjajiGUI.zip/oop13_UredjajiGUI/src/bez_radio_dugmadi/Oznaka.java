package bez_radio_dugmadi;

public enum Oznaka {
	TEL, TAB
}
