package agencija;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AgencijaGUI extends Application {

	private static ArrayList<Ponuda> ponude = new ArrayList<>();

	/* Cvorovi grafa scene za koje se vezuje obrada dogadjaja mogu 
	 * biti deklarisani kao clanice klase, kako bi bile vidljive
	 * u svim metodima. 
	 */
	private TextField unosTF;
	private Button svePonudeBtn, triNajjeftinijihBtn, sveZaDatumBtn, izadjiBtn;
	private TextArea ispisTA;
	
	public static void main(String[] args) {
		ucitajPonude();
		Application.launch(args);
	}

	public static void ucitajPonude() {
		
		try {

			List<String> linije = Files.readAllLines(Paths.get("ponude.txt"), StandardCharsets.UTF_8);

			for (String linija : linije) {

				try (Scanner sc = new Scanner(linija)) {

					sc.useDelimiter(", ");

					String agencija = sc.next();
					String nazivDestinacije = sc.next();

					String datumPolaskaStr = sc.next();
					Datum datumPolaska;
					try (Scanner scDatum = new Scanner(datumPolaskaStr)) {
						scDatum.useDelimiter("\\.");
						datumPolaska = new Datum(scDatum.nextInt(), scDatum.nextInt(), scDatum.nextInt());
					}

					int brojNocenja = sc.nextInt();
					int cena = sc.nextInt();

					Ponuda p = new Ponuda(agencija, nazivDestinacije, datumPolaska, brojNocenja, cena);
					ponude.add(p);
				}
			}

		} catch (IOException e) {
			System.err.println("Greska pri radu sa datotekom.");
		}
	}

	public static String ispisiSvePonude() {
		StringBuilder sb = new StringBuilder();
		for(Ponuda p : ponude)
			sb.append(p + "\n");
		return sb.toString();
	}
	
	public static String ispisiNajjeftinije() {
		StringBuilder sb = new StringBuilder();
		Collections.sort(ponude);
		for(int i = 0; i < 3; i++)
			sb.append(ponude.get(i) + "\n");
		return sb.toString();
	}
	
	public static String ispisiPonudeZaDatum(Datum d) {
		StringBuilder sb = new StringBuilder();
		for(Ponuda p : ponude)
			if(p.getDatumPolaska().equals(d))
				sb.append(p + "\n");
		return sb.toString();
	}

	@Override
	public void start(Stage stage) throws Exception {

		VBox root = new VBox();
		root.setSpacing(15);
		Scene scene = new Scene(root, 1000, 400);
		
		napraviGUI(root);

		stage.setTitle("Turistička agencija");
		stage.setResizable(false);
		stage.setScene(scene);
		stage.show();
	}

	private void napraviGUI(VBox root) {
		
		double width = root.getWidth();
		
		HBox gornjiNivo = new HBox();
		HBox srednjiNivo = new HBox();
		VBox donjiNivo = new VBox();
		
		Label datumLbl = new Label("Unesite datum u formatu dd.mm.gggg:");
		unosTF = new TextField();
		unosTF.setMinWidth(width / 3);
		
		gornjiNivo.setSpacing(15);
		gornjiNivo.setPadding(new Insets(15, 0, 0, 15));
		gornjiNivo.getChildren().addAll(datumLbl, unosTF);

		svePonudeBtn = new Button("Izlistaj ponude");
		svePonudeBtn.setPrefWidth(width / 5);

		triNajjeftinijihBtn = new Button("Najjeftinije ponude");
		triNajjeftinijihBtn.setPrefWidth(width / 5);

		sveZaDatumBtn = new Button("Prikazi za datum");
		sveZaDatumBtn.setPrefWidth(width / 5);

		izadjiBtn = new Button("Kraj");
		izadjiBtn.setPrefWidth(width / 5);

		srednjiNivo.setSpacing(5);
		srednjiNivo.setPadding(new Insets(5, 0, 0, 80));
		srednjiNivo.getChildren().addAll(svePonudeBtn, triNajjeftinijihBtn, sveZaDatumBtn, izadjiBtn);

		ispisTA = new TextArea();
		ispisTA.setPrefSize(width, 280);
		ispisTA.setEditable(false);
		donjiNivo.setPadding(new Insets(0, 5, 0, 5));
		donjiNivo.getChildren().add(ispisTA);
		
		/* obrada dogadjaja */
		obradiListanjePonuda();
		obradiTriNajjeftinije();
		obradiSveZaDatum();
		obradiIzlazak();
		
		root.getChildren().addAll(gornjiNivo, srednjiNivo, donjiNivo);
	}

	private void obradiIzlazak() {
		izadjiBtn.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				Platform.exit();
			}
		});
	}

	private void obradiSveZaDatum() {
		sveZaDatumBtn.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				String datumStr = unosTF.getText();

				try(Scanner scDatum = new Scanner(datumStr)) {
					scDatum.useDelimiter("\\.");
					int dan = scDatum.nextInt();
					int mesec = scDatum.nextInt();
					int godina = scDatum.nextInt();
					Datum zeljeniDatum = new Datum(dan, mesec, godina);
					ispisTA.setText(ispisiPonudeZaDatum(zeljeniDatum));
				}
				catch(Exception e) {
					System.err.println("Neispravan format datuma.");
				}		
			}
		});
	}

	private void obradiTriNajjeftinije() {
		triNajjeftinijihBtn.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				ispisTA.setText(ispisiNajjeftinije());		
			}
		});
	}

	private void obradiListanjePonuda() {
		svePonudeBtn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				ispisTA.setText(ispisiSvePonude());
			}
		});	
	}

}
