package osobe;

import java.util.Objects;

public class Osoba implements Comparable<Osoba> {

	private String ime;
	private String prezime;
	private int godiste;
	
	// indikator koji se koristi za proveru nacina sortiranja
	// postavlja se na odgovarajucu vrednost u test-klasi u zavisnosti
	// od toga koje je radio dugme selektovano
	private static boolean sortirajLeksikografski = true;
	
	public Osoba(String ime, String prezime, int godiste){
		this.ime = ime;
		this.prezime = prezime;
		this.godiste = godiste;
	}
	
	@Override
	public int compareTo(Osoba o) {
		if(sortirajLeksikografski) {
			// sortiranje leksikografski po prezimenu i imenu rastuce
			int rez = prezime.compareTo(o.prezime);
			if(rez != 0)
				return rez;
			rez = ime.compareTo(o.ime);
			if(rez != 0)
				return rez;
			return Integer.compare(o.godiste, godiste);
		}
		else {
			// sortiranje prema godinama starosti rastuce
			return Integer.compare(o.godiste, godiste);
		}
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
			return false;
		if(this == obj)
			return true;
		if(!(obj instanceof Osoba))
			return false;
		return compareTo((Osoba)obj) == 0;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(ime, prezime, godiste);
	}
	
	public static boolean isSortirajLeksikografski() {
		return sortirajLeksikografski;
	}

	public static void setSortirajLeksikografski(boolean sortirajLeksikografski) {
		Osoba.sortirajLeksikografski = sortirajLeksikografski;
	}
	
	public String getIme() {
		return ime;
	}
	
	public String getPrezime() {
		return prezime;
	}
	
	public int getGodiste() {
		return godiste;
	}
	
	public String toString(){
		return prezime + " " + ime + " " + godiste;
	}
}
