package klase_omotaci;

import java.util.Scanner;

/*
 * Primer ilustruje upotrebu nekih korisnih statickih metoda 
 * u klasama omotacima primitivnih tipova.
 */
public class TestKlaseOmotaci {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite dva cela broja:");
		System.out.print("a = ");
		int a = sc.nextInt();
		System.out.print("b = ");
		int b = sc.nextInt();
		
		// maksimum dva cela broja
		System.out.println("max(a, b) = " + Integer.max(a, b));
		// minimum dva cela broja
		System.out.println("min(a, b) = " + Integer.min(a, b));
		// poredjenje celih brojeva
		int rez = Integer.compare(a, b);
		System.out.println(rez == 0 ? "a == b" : (rez > 0 ? "a > b" : "a < b"));
		
		// poredjenje celih brojeva posmatrajuci njihove binarne reprezentacije kao 
		// reprezentacije neoznacenih celih brojeva
		rez = Integer.compareUnsigned(a, b);
		System.out.println("Kao neoznaceni brojevi:");
		System.out.println(rez == 0 ? "a == b" : (rez > 0 ? "a > b" : "a < b"));
		
		Integer aI = Integer.valueOf(a);
		Integer bI = Integer.valueOf(b);
		// poredjenje objekata klase Integer
		rez = aI.compareTo(bI);
		System.out.println("Kao objekti klase Integer:");
		System.out.println(rez == 0 ? "aI == bI" : (rez > 0 ? "aI > bI" : "aI < bI"));
		System.out.println();
		
		System.out.println("Unesite dva realna broja:");
		System.out.print("x = ");
		double x = sc.nextDouble();
		System.out.print("y = ");
		double y = sc.nextDouble();
		
		// maksimum dva realna broja
		System.out.println("max(x, y) = " + Double.max(x, y));
		
		// minimum dva realna broja
		System.out.println("min(x, y) = " + Double.min(x, y));
		
		// poredjenje realnih brojeva
		rez = Double.compare(x, y);
		System.out.println(rez == 0 ? "x == y" : (rez > 0 ? "x > y" : "x < y"));
		
		Double xD = Double.valueOf(x);
		Double yD = Double.valueOf(y);
		// poredjenje objekata klase Double
		rez = yD.compareTo(xD);
		System.out.println("Kao objekti klase Double:");
		System.out.println(rez == 0 ? "yD == xD" : (rez > 0 ? "yD > xD" : "yD < xD"));
		System.out.println();
		
		sc.close();
	}
}