package klase_omotaci;

/* 
 * StringUBroj.java:
 * - ilustruje razne oblike parsiranja numerickih vrednosti iz stringa
 * 
 * - Metod Integer.parseInt(String) izdvaja ceo dekadni broj iz stringa 
 *   koji je zadat kao argument.
 *   Dozvoljene su jedino dekadne cifre, sa eventualnim predznakom '+' ili '-'.
 *   Vodece nule se zanemariju, ali ne i beline.
 *   
 * - Metod Integer.parseInt(String, radix) izdvaja ceo broj iz stringa
 *   pri cemu je broj zadat u sistemu sa osnovom radix.
 *   
 * - Metod Integer.decode(String) izdvaja ceo dekadni, oktalni (vodeca nula)
 *   ili heksadekadni (prefiks '#', '0x' ili '0X') broj iz stringa.
 *   
 * - Metod Double.parseDouble(String) 
 *   zanemaruje vodece nule ili nule na kraju stringa, kao i beline. 
 *   Slova sufiksi (f, d) koja oznacavaju tip realnog literala, 
 *   ne uticu na rezultat metoda.
 * 
 *   Konverzija stringa u float, a potom float u double, 
 *   NIJE EKVIVALENTNA
 *   direktnoj konverziji stringa u double!!!
 */   
public class StringUBroj {

	public static void main(String[] args) {

		// probati i zakomentarisane varijante
		String strI = "";

		strI = "12"; // ok
//		strI = "012"; // ok
//		strI = "+012"; // ok
//		strI = "-12"; // ok
//		strI = " -12"; // ne!, sa trim() da!
		int br = Integer.parseInt(strI);
//		int br = Integer.parseInt(strI.trim());
		System.out.println("Ceo broj: " + br);
		
		/* Metod Integer.parseInt() moze da izbaci izuzetak tipa NumberFormatException,
		 * ukoliko string ne odgovara formatu celog broja
		 */
//		strI = "-128"; // oktalni sistem -ne!, heksadekadni -da!
		br = Integer.parseInt(strI, 8);
		System.out.println("Ceo broj (oktalno): " + br);
//		strI = "-FF"; // -255
		br = Integer.parseInt(strI, 16);
		System.out.println("Ceo broj (heksadekadno): " + br);
		
		System.out.println();
		
		strI = "-012"; // vodeca nula - oktalni broj
//		strI = "-#12"; // # - heksadekadni broj
//		strI = "-0x12"; // 0x ili 0X - heksadekadni broj
		// Metod Integer.decode() moze da parsira dekadnu, okalnu ili heksadekadnu 
		// numericku vrednost iz stringa
		br = Integer.decode(strI);
		System.out.println("Ceo broj: " + br);
		System.out.println();
		
		String str = "";
		
//		str = "12d"; // ok, parseInt() - ne!
//		str = "0012.5"; // vodece nule, ok!
//		str = "12.500"; // zavrsne nule, ok!
//		str = "  12.5 "; // vodece i zavrsne beline, ok!
		str = "  012.50d";  // ok
		
//		str = "0.1f"; // parseFlout(), a zatim parseDouble()
						// parseDouble()
		
		float brF = Float.parseFloat(str);
		double brD = brF;
		System.out.println("Realan broj (string -> float) " + brF);
		System.out.println("Realan broj (float -> double) " + brD);
		
		brD = Double.parseDouble(str);
		System.out.println("Realan broj (string -> double) " + brD);
		
		/* Metodi Float.parseFloat() i Double.parseDouble() takodje mogu da izbace izuzetak tipa 
		 * NumberFormatException,
		 * ukoliko string ne odgovara formatu realnog broja */
		
	}
}
