package povrs_protected_centar;

public class Krug extends Povrs
{
	private double radius;
	
	public Krug(double radius) {
		// super();
		this.radius = radius;
	}
	
	public Krug(Tacka centar, double radius) {
		super(centar);
		this.radius = radius;	
	}
	
	public Krug(final Krug k) {
		// k.centar sada moze
		this(k.centar, k.radius);
	}
	
	public double povrsina() {
		return radius * radius * Math.PI;
	}
	
	public Krug izvedenaPovrs() {
		return new Krug(
				new Tacka(
					centar.getX() == 0 ? centar.getX() : -centar.getX(),
					centar.getY() == 0 ? centar.getY() : -centar.getY() ),
				radius * 2);
	}
	
	public String toString() {
		return String.format("krug " + super.toString() + " poluprecnik je %.2f", radius);
	}
}
