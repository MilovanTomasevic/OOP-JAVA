package povrs_protected_centar;

public class Pravougaonik extends Povrs 
{
	protected double a;
	protected double b;
	
	public Pravougaonik(double a, double b) {
		// super();
		this.a = a;
		this.b = b;
	}
	
	public Pravougaonik(Tacka centar, double a, double b) {
		super(centar);
		this.a = a;
		this.b = b;
	}
	
	public Pravougaonik(final Pravougaonik p) {
		this(p.centar, p.a, p.b);
	}
	
	public double dijagonala() {
		return Math.sqrt(a*a + b*b);
	}
	
	public Krug opisaniKrug() {
		return new Krug(centar, 0.5*dijagonala());
	}
	
	public double povrsina() {
		return a*b;
	}
	
	public Pravougaonik izvedenaPovrs() {
		return new Pravougaonik(
				new Tacka(
						centar.getX() == 0 ? centar.getX() : -centar.getX(),
						centar.getY() == 0 ? centar.getY() : -centar.getY() ),
				b, a);
	}
	
	public String toString() {
		return String.format("pravougaonik " + super.toString() + " a = %.2f b = %.2f", a, b);
	}
}
