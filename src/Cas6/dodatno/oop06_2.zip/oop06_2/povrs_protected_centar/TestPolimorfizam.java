package povrs_protected_centar;

import java.util.Random;

public class TestPolimorfizam {

	public static void main(String[] args) 
	{
		Povrs povrsi[] = { 
				new Krug(new Tacka(),1),
				new Krug(new Tacka(1,1),2),
				new Pravougaonik(new Tacka(),3,4),
				new Kvadrat(new Tacka(4,6), 2) 
		};
		
		Random izbor = new Random();
		
		for(int i=0; i<5; i++)
		{
			Povrs p = povrsi[izbor.nextInt(povrsi.length)];
			System.out.println(p); // Polimorfno se poziva metod toString()
			         // koji takodje ispunjava uslove za polimorfizam
			// Polimorfno pozivanje metoda povrsina()
			System.out.printf("Povrsina je %.2f\n", p.povrsina());
			// Polimorfno pozivanje metoda za generisanje nove povrsi primenom transformacije
			System.out.println("Nova povrs nakon transformacije: " + p.izvedenaPovrs());
			
			// Kastovanje nanize kroz hijerarhiju klasa:
			// provera da li je dopusteno kastovati tip objekta na koji ukazuje referenca p 
			// u tip Pravougaonik
			if(p instanceof Pravougaonik)
				System.out.println("Opisani "+ ((Pravougaonik)p).opisaniKrug());
			
			if(p.getClass() == Pravougaonik.class)
				System.out.println("Klasa objekta je Pravougaonik");
			else
				System.out.println("Klasa objekta je " + p.getClass().getName());
			
			System.out.println();
		}
	}
}