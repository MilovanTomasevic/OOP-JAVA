package povrs_protected_centar;

public class Kvadrat extends Pravougaonik 
{
	public Kvadrat(double a) {
		super(a, a);
	}
	
	public Kvadrat(Tacka centar, double a) {
		super(centar, a, a);
	}
	
	public Kvadrat(final Kvadrat k) {
		super(k);
	}

	public Kvadrat izvedenaPovrs() {
		return new Kvadrat(
				new Tacka(
					centar.getX() == 0 ? centar.getX() : -centar.getX(),
					centar.getY() == 0 ? centar.getY() : -centar.getY() ),
				dijagonala());
	}
	
	public String toString() {
		return String.format("kvadrat centar je u tacki " + centar + " a = %.2f", a);
	}
}

