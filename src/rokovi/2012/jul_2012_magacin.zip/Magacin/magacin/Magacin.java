package magacin;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;



public class Magacin extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JTextField proizvod = new JTextField(20);
	private JTextField kolicina = new JTextField(5);
	private JTextField cena = new JTextField(5);
	private JTextField ukupnavrednost = new JTextField(5);
	private JTextField tip = new JTextField(2);
	
	private JLabel Lkolicina = new JLabel("Kom");
	private JLabel Lcena = new JLabel("RSD");
	
	private JRadioButton Rcaj = new JRadioButton("Caj",true);
	private JRadioButton Rsok = new JRadioButton("Sok",false);
	private JRadioButton Rvele = new JRadioButton("Veleprodaja",true);
	private JRadioButton Rmalo = new JRadioButton("Maloprodaja",false);
	private JRadioButton Rpc = new JRadioButton("Caj",true);
	private JRadioButton Rps = new JRadioButton("Sok",false);
	
	private JButton unesi = new JButton("Unesi");
	private JButton ponisti = new JButton("Ponisti");
	
	private ButtonGroup grupa1 = new ButtonGroup();
	private ButtonGroup grupa2 = new ButtonGroup();
	private ButtonGroup grupa3 = new ButtonGroup();
	
	
	private Vector<Proizvod> proizvodi = new Vector<Proizvod>();
	
	private JButton stampaj = new JButton("Stampaj ponudu");


	public Magacin() {
	
		setTitle("Magacin");
		
		Container content = getContentPane();
		content.setLayout(new GridLayout(0,1));
		
		FlowLayout flow = new FlowLayout(FlowLayout.LEFT,10,2);
		JPanel p1 = new JPanel(flow); content.add(p1);
		JPanel p2 = new JPanel(flow); content.add(p2);
		JPanel p3 = new JPanel(flow); content.add(p3);
		JPanel p4 = new JPanel(flow); content.add(p4);
		JPanel p5 = new JPanel(flow); content.add(p5);
		JPanel p6 = new JPanel(flow); content.add(p6);
		JPanel p7 = new JPanel(flow); content.add(p7);
		JPanel p8 = new JPanel(flow); content.add(p8);
		
		p1.add(new JLabel("Proizvod         ")); p1.add(proizvod);
		p2.add(new JLabel("Tip Proizvoda ")); p2.add(Rcaj); p2.add(Rsok);
		grupa1.add(Rcaj); grupa1.add(Rsok);
		p3.add(new JLabel("Kolicina         ")); p3.add(kolicina);  p3.add(Lkolicina);
		p4.add(new JLabel("Cena             ")); p4.add(cena);      p4.add(Lcena);
		p5.add(unesi); p5.add(ponisti);
		p6.add(Rvele); p6.add(Rmalo);
		grupa2.add(Rvele); grupa2.add(Rmalo);
		p7.add(new JLabel("Ukupna cena svih proizvoda ")); p7.add(tip);
		p7.add(new JLabel(" je: ")); p7.add(ukupnavrednost); p7.add(new JLabel("RSD"));
		ukupnavrednost.setEditable(false);
		p8.add(new JLabel("Prosecna cena")); p8.add(Rpc); p8.add(Rps);
		grupa3.add(Rpc); grupa3.add(Rps);
		p8.add(stampaj);
		
		Rcaj.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				Lkolicina.setText("Kom");
			}
		});
		Rsok.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				Lkolicina.setText("L");
			}
		});
		Rvele.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				if(tip.getText().equals("K") || tip.getText().equals("N") || tip.getText().equals("Z")){
					int sum = 0;
					for(Proizvod p : proizvodi){
						String sifra = p.getime().charAt(0) +"";
						if(sifra.equals(tip.getText())){
							sum=sum+p.getcena()*p.getkol();
						}
					}
 
					ukupnavrednost.setText(sum*0.7 +"");
				}else{
					JOptionPane.showMessageDialog(Rvele, "nekorektan unos");
					return;
				}
			}
		});
		Rmalo.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				if(tip.getText().equals("K") || tip.getText().equals("N") || tip.getText().equals("Z")){
					int sum = 0;
					for(Proizvod p : proizvodi){
						String sifra = p.getime().charAt(0) +"";
						if(sifra.equals(tip.getText())){
							sum=sum+p.getcena()*p.getkol();
						}
						
					}
					ukupnavrednost.setText(sum+"");
				}else{
					JOptionPane.showMessageDialog(Rvele, "nekorektan unos");
					return;
				}
			}
		});
		ponisti.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				proizvod.setText("");
				kolicina.setText("");
				cena.setText("");
				Rcaj.setSelected(true);
			}
		});
		
		unesi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String s = proizvod.getText();
				if(!s.equals("Kopriva") && !s.equals("Nana") && !s.equals("Zova")){
					JOptionPane.showMessageDialog(proizvod, "nekorektan unos imena proizvoda");
					return;
				}
				int koliko=0,posto=0;
				try {
					koliko = Integer.parseInt(kolicina.getText());
				} catch (NumberFormatException e1) {
					JOptionPane.showMessageDialog(kolicina, "nekorektan unos kolicine");
					return;
				}
				try {
					posto = Integer.parseInt(cena.getText());
				} catch (NumberFormatException e1) {
					JOptionPane.showMessageDialog(cena, "nekorektan unos cene");
					return;
				}
				String t ="";
				if(Rcaj.isSelected()) t="Caj";
				else                  t="Sok";
				
				Proizvod trenutni = new Proizvod(s, t, koliko, posto);
				
				File f = new File("Proizvodi.bin");
				if(f.exists()){
					
						try {
							ObjectInputStream in = new ObjectInputStream(new FileInputStream(f));
							proizvodi = (Vector<Proizvod>) in.readObject();
							in.close();
						} catch (FileNotFoundException e1) {
							e1.printStackTrace();
						} catch (IOException e1) {
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							e1.printStackTrace();
						}
						proizvodi.add(trenutni);
						
						try {
							ObjectOutputStream out = new ObjectOutputStream( new FileOutputStream(f));
							out.writeObject(proizvodi);
							out.close();
						} catch (FileNotFoundException e1) {
							e1.printStackTrace();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
				}else {
					
					proizvodi.add(trenutni);
					
					try {
						ObjectOutputStream out = new ObjectOutputStream( new FileOutputStream(f));
						out.writeObject(proizvodi);
						out.close();
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					
				}
				
			}
		});
	
		stampaj.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				PrintWriter out = null;
				try {
					out = new PrintWriter("izlaz.txt");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				String tip = "";
				if (Rpc.isSelected()) tip="Caj";
				else				  tip="Sok";	
				double sum = 0;
				int broj = 0;
				for(Proizvod p : proizvodi){
					if ( p.gettip().equals(tip) ){
						sum = sum + p.getkol()*p.getcena();
						broj=broj + p.getkol();
						out.println(p);						
					}

				}
				if(broj == 0) out.println("0");
				else {
						if(Rvele.isSelected()) out.println((sum/broj)*0.7);
						else				   out.println(sum/broj);
				}
				out.close();							
			}
		});
		
	}
}
