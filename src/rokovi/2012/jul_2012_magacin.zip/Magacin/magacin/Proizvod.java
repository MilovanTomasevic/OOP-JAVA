package magacin;

import java.io.Serializable;

public class Proizvod implements Serializable{
	private static final long serialVersionUID = 1L;
	private String ime;
	private String tip ;
	private int kol;
	private int cena;
	
	public Proizvod(String s, String a, int b ,int c){
		ime=s;
		tip=a;
		kol=b;
		cena=c;
	}
	
	public String gettip(){
		return tip;
	}
	
	public int getkol(){
		return kol;
	}
	public int getcena(){
		return cena;
	}
	
	public String getime(){
		return ime;
	}
	
	public String toString(){
	   return ime + " " + kol + " " + cena; 
	}
	
}
