package magacin;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Test {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(
				new Runnable(){ 
					public void run(){
							kreirajGUI();
					}
				});
	}
	
	public static void kreirajGUI(){
		Magacin prozor = new Magacin();
		prozor.setSize(420, 400);
		prozor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		prozor.setLocationRelativeTo(null);
		prozor.setVisible(true);
	}

	

}
