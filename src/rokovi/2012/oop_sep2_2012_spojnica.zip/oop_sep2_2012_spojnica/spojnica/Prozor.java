package spojnica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileFilter;

public class Prozor extends JFrame
{
	private static final long serialVersionUID = 1L;
	
	private JFileChooser fc;
	private JButton dugmeUcitaj;
	private JPanel panelSever;
	private JPanel panelCentar;
	private JPanel panelJug;
	private JPanel centarLevo;
	private JPanel centarDesno;
	// umesto nizova dugmadi i tekstualnih polja mogu se koristiti i kolekcije
	private JButton[] dugmadLevo;
	private JTextField[] checkLevo;
	private JButton[] dugmadDesno;
	private JTextField[] checkDesno;
	private JButton dugmeKraj;
	// katalog sluzi za uparivanje pojmova (koristi se u obradi dogadjaja za dugme Kraj)
	private Map<String, String> parovi = new HashMap<String, String>();
	private List<String> pojmoviL;
	private List<String> pojmoviD;
	private int brredova = 0;
	private int brojac = 0;
	
	public Prozor() {
		super();
		inicijalizuj();
	}
	
	private void inicijalizuj() {
		this.setSize(650, 400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Spojnica");
		Container content = getContentPane();
		
		fc = new JFileChooser(".");
		fc.setFileFilter(new FileFilter() {
			@Override
			public String getDescription(){
				return "Text files (*.txt)";
			}
			@Override
			public boolean accept(File f) {
				return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
			}
		});
		content.setLayout(new BorderLayout());
		panelSever = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelSever.add((dugmeUcitaj = new JButton("Ucitaj")));
		dugmeUcitaj.setPreferredSize(new Dimension(80, 30));
		dugmeUcitaj.setBackground(Color.gray);
		dugmeUcitaj.setForeground(Color.white);
		content.add(panelSever, BorderLayout.NORTH);
		dugmeUcitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				int rez = fc.showOpenDialog(null);
				if(rez == JFileChooser.APPROVE_OPTION){
					Scanner sc = null;
					try {
						sc = new Scanner(fc.getSelectedFile());
						while(sc.hasNextLine())
						{
							String[] par = sc.nextLine().split("->");
							brredova++;
							parovi.put(par[0].trim(), par[1].trim());
						}
						// proizvoljno se mesaju liste termina koji se uparuju
						pojmoviL = new ArrayList<String>(parovi.keySet());
						Collections.shuffle(pojmoviL);
						pojmoviD = new ArrayList<String>(parovi.values());
						Collections.shuffle(pojmoviD);
						
						dugmadLevo = new JButton[brredova];
						checkLevo = new JTextField[brredova];
						dugmadDesno = new JButton[brredova];
						checkDesno = new JTextField[brredova];
						
						for(int i = 0; i < brredova; i++)
						{
							JPanel redL = new JPanel();
							redL.add((dugmadLevo[i] = new JButton(pojmoviL.get(i))));
							dugmadLevo[i].setPreferredSize(new Dimension(270, 30));
							dugmadLevo[i].setBackground(Color.gray);
							dugmadLevo[i].setForeground(Color.white);
							final int I = i;
							dugmadLevo[i].addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e)
								{
									// ako se u polju pored dugmeta vec nalazi zvezdica 
									if(checkLevo[I].getText().equals("*"))
										checkLevo[I].setText(""); // ukloniti je 
									else if(checkLevo[I].getText().equals("")) { // inace 
										// ako u istoj koloni postoji polje/polja sa zvezdicom, ukloniti je/ih 
										for(int j = 0; j < checkLevo.length; j++)
											if(checkLevo[j].getText().equals("*"))
												checkLevo[j].setText("");
										checkLevo[I].setText("*"); // postaviti zvezdicu 
										// i proveriti stanje tekstualnih polja u desnoj koloni 
										for(int j = 0; j < checkDesno.length; j++) 
											// ako postoji tekstualno polje sa zvezdicom
											if(checkDesno[j].getText().equals("*")) {
												checkDesno[j].setText((++brojac) + ""); // upisati umesto zvezdice odgovarajuci broj
												checkDesno[j].setBackground(Color.green); // promeniti boju pozadine na zelenu
												checkLevo[I].setText(brojac + ""); // isti broj upisati i u tekstualno polje u levoj koloni
												checkLevo[I].setBackground(Color.green); // i promeniti mu boju pozadine
												dugmadLevo[I].setBackground(Color.green); // promeniti boju pozadine odgovarajucih dugmadi
												dugmadDesno[j].setBackground(Color.green);
										}
									}
									else { // u pitanju je broj, tj. polje je vec upareno, ponistava se uparivanje 
										brojac--;
										for(int j = 0; j < dugmadDesno.length; j++) 
											if(checkDesno[j].getText().equals(checkLevo[I].getText())) {
												checkDesno[j].setText("");
												dugmadDesno[j].setBackground(Color.gray);
												checkDesno[j].setBackground(Color.red);
											}
										checkLevo[I].setText("");
										dugmadLevo[I].setBackground(Color.gray);
										checkLevo[I].setBackground(Color.red);
									}
								}
							});
							redL.add((checkLevo[i] = new JTextField()));
							checkLevo[i].setPreferredSize(new Dimension(30, 30));
							checkLevo[i].setBackground(Color.red);
							checkLevo[i].setForeground(Color.white);
							checkLevo[i].setEditable(false);
							checkLevo[i].setHorizontalAlignment(JTextField.CENTER);
							centarLevo.add(redL);
							JPanel redD = new JPanel();
							redD.add((checkDesno[i] = new JTextField()));
							checkDesno[i].setBackground(Color.red);
							checkDesno[i].setPreferredSize(new Dimension(30, 30));
							checkDesno[i].setForeground(Color.white);
							checkDesno[i].setEditable(false);
							checkDesno[i].setHorizontalAlignment(JTextField.CENTER);
							redD.add((dugmadDesno[i] = new JButton(pojmoviD.get(i))));
							dugmadDesno[i].setPreferredSize(new Dimension(270, 30));
							dugmadDesno[i].setBackground(Color.gray);
							dugmadDesno[i].setForeground(Color.white);
							// obrada dogadjaja za dugmad u desnoj koloni je simetricna obradi dogadjaja za dugmad iz leve kolone
							dugmadDesno[i].addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e)
								{
									if(checkDesno[I].getText().equals("*"))
										checkDesno[I].setText("");
									else if(checkDesno[I].getText().equals("")) {
										for(int j = 0; j < checkDesno.length; j++)
											if(checkDesno[j].getText().equals("*"))
												checkDesno[j].setText("");
										checkDesno[I].setText("*");
										for(int j = 0; j < checkLevo.length; j++) 
											if(checkLevo[j].getText().equals("*")) {
												checkLevo[j].setText((++brojac) + "");
												checkLevo[j].setBackground(Color.green);
												checkDesno[I].setText(brojac + "");
												checkDesno[I].setBackground(Color.green);
												dugmadLevo[j].setBackground(Color.green);
												dugmadDesno[I].setBackground(Color.green);
										}
									}
									else { // u pitanju je broj, tj. polje je vec upareno, ponistava se uparivanje
										brojac--;
										for(int j = 0; j < checkLevo.length; j++) 
											if(checkLevo[j].getText().equals(checkDesno[I].getText())) {
												checkLevo[j].setText("");
												dugmadLevo[j].setBackground(Color.gray);
												checkLevo[j].setBackground(Color.red);
											}
										checkDesno[I].setText("");
										dugmadDesno[I].setBackground(Color.gray);
										checkDesno[I].setBackground(Color.red);
									}
								}
							});
							centarDesno.add(redD);
						}
						centarLevo.validate();
						centarDesno.validate();
						dugmeUcitaj.setEnabled(false);
						dugmeKraj.setEnabled(true);
					}
					catch (FileNotFoundException e1) {
						return;
					} finally{
						if(sc!=null)
							sc.close();
					}			
				}
			}
		});
		panelCentar = new JPanel(new GridLayout(1, 2));
		panelCentar.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.gray), 
				"Spojnica", TitledBorder.RIGHT, TitledBorder.TOP));
		centarLevo = new JPanel(new GridLayout(0, 1));
		centarDesno = new JPanel(new GridLayout(0, 1));
		panelCentar.add(centarLevo);
		panelCentar.add(centarDesno);
		content.add(panelCentar, BorderLayout.CENTER);
		
		panelJug = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelJug.add((dugmeKraj = new JButton("Kraj")));
		dugmeKraj.setPreferredSize(new Dimension(80, 30));
		dugmeKraj.setBackground(Color.gray);
		dugmeKraj.setForeground(Color.white);
		dugmeKraj.setEnabled(false);
		content.add(panelJug, BorderLayout.SOUTH);
		dugmeKraj.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				System.out.println("Kraj igre!");
				System.out.println("Tacni odgovori su:\n");
				for(int i = 0; i < brredova; i++)
				{
					String linija = pojmoviL.get(i) + " - " + parovi.get(pojmoviL.get(i));
					for(int j = 0; j < brredova; j++)
						if(!checkLevo[i].getText().equals("") && 
							checkLevo[i].getText().equals(checkDesno[j].getText()) &&
							parovi.get(pojmoviL.get(i)).equals(dugmadDesno[j].getText()))
							linija += " + ";
					System.out.println(linija);
				}
			}
		});
	}
}