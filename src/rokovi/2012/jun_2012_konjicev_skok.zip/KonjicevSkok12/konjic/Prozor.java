package konjic;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

public class Prozor extends JFrame{
	
	private JPanel slovaPanel;
	private JButton[][] polja;
	private JLabel rezultatL;
	
	private JFileChooser fc;
	private JButton fajlBt;
	private JButton vratiBt;
	
	private int tekuceI;
	private int tekuceJ;
	
	private Stack<Integer> potezi = new Stack<Integer>();
	
	private int brPoteza;
	private int ukupanBrPoteza;
	
	public Prozor(String naslov){
		super(naslov);
		
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){
			
		}
		
		Container content = getContentPane();
		
		fc = new JFileChooser(".");
		fc.setFileFilter(new FileFilter() {
			
			@Override
			public String getDescription() {
				return "Text files (*.txt)";
			}
			
			@Override
			public boolean accept(File f) {
				return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
			}
		});
		
		JPanel severPanel = new JPanel();
		fajlBt = new JButton("Ucitaj iz fajla");
		fajlBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int rez = fc.showOpenDialog(null);
				if(rez==JFileChooser.APPROVE_OPTION){
					Scanner sc = null;
					try {
						sc = new Scanner(fc.getSelectedFile());
						// citamo sta treba iz fajla
						int brVrsta = 0;
						String slova[] = null;
						Vector<String> slovaVector = new Vector<String>();
						while(sc.hasNextLine()){
							String linija = sc.nextLine();
							brVrsta++;
							slova = linija.split(";");
							for(String s: slova)
								slovaVector.add(s);
						}
						int brKolona = slova.length;
						
						slovaPanel.setLayout(new GridLayout(brVrsta, brKolona));
						polja = new JButton[brVrsta][brKolona];
						for(int i=0; i<polja.length; i++)
							for(int j=0; j<polja[i].length; j++){
								String slovo = slovaVector.remove(0);
								polja[i][j] = new JButton(slovo);
								if(slovo.trim().length()==0)
									polja[i][j].setVisible(false);
								else{
									ukupanBrPoteza++;
									polja[i][j].setBackground(Color.YELLOW);
									final int I=i;
									final int J=j;
									polja[i][j].addActionListener(new ActionListener() {
										
										@Override
										public void actionPerformed(ActionEvent e) {

											if(polja[I][J].getBackground().equals(Color.YELLOW) && 
												   (Math.abs(I-tekuceI)==2 && Math.abs(J-tekuceJ)==1 ||
													Math.abs(I-tekuceI)==1 && Math.abs(J-tekuceJ)==2)){
												polja[tekuceI][tekuceJ].setBackground(Color.GREEN);
												potezi.push(tekuceI);
												potezi.push(tekuceJ);
												brPoteza++;
												polja[I][J].setBackground(Color.RED);
												tekuceI = I;
												tekuceJ = J;
												rezultatL.setText(rezultatL.getText()+polja[I][J].getText());
												
												// provera da li je kraj, II nacin
												/* boolean kraj = true;
												for(int i=0; i<polja.length; i++)
													for(int j=0; j<polja[i].length; j++)
														 if(polja[i][j].isVisible() && polja[i][j].getBackground().equals(Color.YELLOW)){
															 kraj = false;
															 break;
														 }
												*/
												boolean kraj = brPoteza==ukupanBrPoteza;
												if(kraj){
													rezultatL.setForeground(Color.GREEN);
													vratiBt.setEnabled(false);
												}														 
											}else
												JOptionPane.showMessageDialog(polja[I][J], "Ne mozete skociti tu");
										}
									});
								}
								slovaPanel.add(polja[i][j]);
							}
						
						// prvo slovo u prvom redu treba da bude crveno
						for(int j=0; j<polja[0].length; j++)
							if(polja[0][j].isVisible()){
								polja[0][j].setBackground(Color.red);
								rezultatL.setText(polja[0][j].getText());
								tekuceI = 0;
								tekuceJ = j;
								brPoteza=1;
								break;
							}
						slovaPanel.validate();
					} catch (FileNotFoundException e1) {
						return; // ne bi trebalo da se desi
					} finally{
						if(sc!=null)
							sc.close();
					}				
					fajlBt.setEnabled(false);
					vratiBt.setEnabled(true);
				}
			}
		});
		severPanel.add(fajlBt);
		content.add(severPanel, BorderLayout.NORTH);
		
		slovaPanel = new JPanel();
		content.add(slovaPanel, BorderLayout.CENTER);
		
		JPanel rezultatPanel = new JPanel();
		rezultatL = new JLabel();
		rezultatL.setPreferredSize(new Dimension(400, 30));
		rezultatPanel.add(rezultatL);
		
		vratiBt = new JButton("VRATI");
		vratiBt.setEnabled(false);
		vratiBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!potezi.empty()){
					polja[tekuceI][tekuceJ].setBackground(Color.YELLOW);
					tekuceJ = potezi.pop();
					tekuceI = potezi.pop();
					brPoteza--;
					polja[tekuceI][tekuceJ].setBackground(Color.RED);
					String rezultat = rezultatL.getText();
					int duzina = rezultat.length();
					rezultatL.setText(rezultat.substring(0, duzina-3));
				}				
			}
		});
		rezultatPanel.add(vratiBt);
		content.add(rezultatPanel, BorderLayout.SOUTH);	
	}
}