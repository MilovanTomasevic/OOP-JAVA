package konjic;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class TestKonjic {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				createGUI();
			}
		});
	}
	
	public static void createGUI(){
		Prozor prozor = new Prozor("Konjicev skok");
		prozor.setSize(600, 400);
		prozor.setLocationRelativeTo(null);
		prozor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		prozor.setVisible(true);
	}
}
