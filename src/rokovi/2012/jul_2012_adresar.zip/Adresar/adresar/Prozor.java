package adresar;


import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JFileChooser;

public class Prozor extends JFrame{
	
	private Vector<Kontakt> kolekcija = new Vector<Kontakt>();
	private File fajl = new File("adresar.izlaz");
	
	// komponente kojima se pristupa iz obrade dogadjaja definisane
	// su kao final lokalne promenljive, a mogle su da budu i ovde,
	// kao atributi klase Prozor
	
	public Prozor(String naslov)
	{	
		super(naslov);
		
		Container content = getContentPane();
		content.setLayout(new GridLayout(0,1));
		
		JPanel imePanel=new JPanel();
		imePanel.setLayout(new GridLayout(0,1));
		JLabel imeLabel = new JLabel("Ime i prezime");
		imePanel.add(imeLabel);
		final JTextField imeTekst = new JTextField(20);
		imePanel.add(imeTekst);
		
		content.add(imePanel);		
		
		JPanel gradPanel=new JPanel();
		gradPanel.setLayout(new GridLayout(0,1));
		JLabel gradLabel = new JLabel("Grad");
		gradPanel.add(gradLabel);		
		final JTextField gradTekst = new JTextField(20);
		gradPanel.add(gradTekst);
		
		content.add(gradPanel);
				
		JPanel komanda = new JPanel();
		final JButton ucitajBT = new JButton("Ucitaj");
		komanda.add(ucitajBT);
		final JButton dodajBT = new JButton("Dodaj");
		komanda.add(dodajBT);
		final JButton ponistiBT = new JButton("Ponisti");
		komanda.add(ponistiBT);
	
		content.add(komanda);

		ucitajBT.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0) {
				final JFileChooser fc = new JFileChooser(".");
				int rez = fc.showOpenDialog(null);
								
				if(rez==JFileChooser.APPROVE_OPTION){
					fajl = fc.getSelectedFile();
					ObjectInputStream in = null;
					try {
						in = new ObjectInputStream(
								new BufferedInputStream(
										new FileInputStream(fajl)));					
						kolekcija = (Vector<Kontakt> )in.readObject();
						ucitajBT.setEnabled(false);
						
					} catch (IOException e) { 
						imeTekst.setText("Fajl je neispravnog formata");
					} catch (ClassNotFoundException e) {
						imeTekst.setText("Fajl je neispravnog formata");
					} finally{ 
						if(in!=null)
							try {
								in.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
					}
				}
				else{
					imeTekst.setText("Niste izabrali fajl. Pokusajte ponovo!");
				}
				
				
			}
			
		});
		
		ponistiBT.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0) {
				imeTekst.setText("");
				gradTekst.setText("");				
			}
			
		});
		
		dodajBT.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
					String imeStr = imeTekst.getText().trim();
					String gradStr = gradTekst.getText().trim();
					if(imeStr.equals("") || gradStr.equals("")){
						imeTekst.setText("Uneli ste prazan string");
						return;
					}
						
					Kontakt nov = new Kontakt(imeStr, gradStr);
					kolekcija.add(nov);
 
					
					ucitajBT.setEnabled(false);				
					// mozda je vec onemoguceno, ako je klikom na ucitaj izabran fajl,
					// ali ako nije, sada ga treba onemoguciti, a bice koriscen podrazumevani fajl
					// "adresar.izlaz"

					ObjectOutputStream out = null;
					try {
						out = new ObjectOutputStream(
								new BufferedOutputStream(
										new FileOutputStream(fajl )));


						out.writeObject(kolekcija);
					
					} catch (IOException e) {
						e.printStackTrace();
					} finally { 
						if(out!=null)
							try {
								out.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
					}	

			}

		});

		
		JPanel slovoPanel = new JPanel();
		slovoPanel.add(new JLabel("Slovo"));
		final JTextField slovoTekst = new JTextField(2);
		slovoPanel.add(slovoTekst);
		content.add(slovoPanel);
		
		JPanel izbor = new JPanel();
		izbor.setLayout(new GridLayout(0,1));
		final JRadioButton poImenu = new JRadioButton("Ime i prezime", true);
		izbor.add(poImenu);
		final JRadioButton poGradu = new JRadioButton("Grad");
		izbor.add(poGradu);
		ButtonGroup izb  = new ButtonGroup();
		izb.add(poImenu);
		izb.add(poGradu);
		
		content.add(izbor);

		JPanel ispisPanel = new JPanel();
		final JButton ispis = new JButton("Ispisi");
		ispisPanel.add(ispis);
		content.add(ispisPanel);
		
		ispis.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {

				Kontakt.setPoImenu(poImenu.isSelected());
				Collections.sort(kolekcija);
								
				String sl=slovoTekst.getText();
				PrintWriter izl = null;
				try {
					izl = new PrintWriter(new FileWriter("izlaz.txt"));
					for(int i=0; i<kolekcija.size(); i++){
						if(kolekcija.get(i).odgovara(sl))
							izl.println(kolekcija.get(i));
					} 
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					if(izl!=null)
						izl.close(); // bitno je zatvoriti fajl da podaci ne bi ostali u baferu
				}
			}
			
		});
		
		JPanel donji = new JPanel();
		donji.setLayout(new GridLayout(1,2));
		JPanel adresarPanel = new JPanel();
		final JLabel adresarLB = new JLabel("Adresar");
		adresarPanel.add(adresarLB);
		donji.add(adresarPanel);
		JPanel zaKrajPanel = new JPanel();
		final JButton zaKraj = new JButton("Kraj rada");
		zaKrajPanel.add(zaKraj);
		donji.add(zaKrajPanel);
		
		content.add(donji);
		
		zaKraj.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				adresarLB.setText("Adresar formiran");
				imeTekst.setEditable(false);
				gradTekst.setEditable(false);
				ucitajBT.setEnabled(false);
				dodajBT.setEnabled(false);
				ponistiBT.setEnabled(false);
				slovoTekst.setEditable(false);
				poImenu.setEnabled(false);
				poGradu.setEnabled(false);
				ispis.setEnabled(false);
				zaKraj.setEnabled(false);
			}
			
		});
	}

}
