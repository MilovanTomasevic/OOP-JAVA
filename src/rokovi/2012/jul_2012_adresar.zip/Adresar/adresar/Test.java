package adresar;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;


public class Test {

	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			
			public void run() {
				createGUI();
			}
		});
		
	}
	
	public static void createGUI(){
		Prozor prozor = new Prozor("Adresar");
		
		prozor.pack(); // dimenzija prozora bice prilagodjena njegovom sadrzaju
		
		// centriranje prozora na ekranu
		prozor.setLocationRelativeTo(null);
		
		prozor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		prozor.setVisible(true);
	}

}
