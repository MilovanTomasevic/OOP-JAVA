package adresar;

import java.io.Serializable;

public class Kontakt implements Serializable, Comparable<Kontakt>{
	private String ime,  grad;
	private static boolean poImenu = true;
	public  Kontakt(String ime, String grad)
	{		
		this.ime = ime;
		this.grad = grad;
		
	}
	
    public static void setPoImenu(boolean a)
    {
    	poImenu=a;
    }
    
	@Override
	public int compareTo(Kontakt drugi) {
		// TODO Auto-generated method stub
		if(poImenu)
		{
			int k=ime.compareTo(drugi.ime);
			if(k!=0) return k;
			// ako ih ima vise sa istim imenom i prezimenom,
			// bice uredjeni po gradu (ovo i nije moralo)
			return grad.compareTo(drugi.grad);
		}
		
		int k=grad.compareTo(drugi.grad);
		if(k!=0) return k;
		// u okviru istog grada, bice uredjeni po prezimenu i imenu (ovo i nije moralo)
		return ime.compareTo(drugi.ime);
	}
	
	// s je string unet u tekstualno polje "slovo"
	public boolean odgovara(String s)
	{
		// ako nije nista uneto, svaki kontakt odgovara
		if(s.equals(""))
			return true;
		// a inace kontakt odgovara ako prezime pocinje trazenim slovom
		return ime.charAt(0)==s.charAt(0);

	}
	
	public String toString()
	{
		return ime+" "+grad;
	}
}
