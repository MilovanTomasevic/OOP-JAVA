package anagrami;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileFilter;

public class Prozor extends JFrame
{
	private static final long serialVersionUID = 1L;
	
	private JFileChooser fc;
	private JButton ucitaj;
	private JPanel panelSever;
	private JPanel panelCentar;
	private JPanel panelJug;
	private JPanel centarAnag;
	private JTextArea centarRez;
	private JScrollPane spane;
	private JPanel anagLevo;
	private JPanel anagDesno;
	private JRadioButton[] kljuceviB;
	private JCheckBox[] anagramiB;
	private JButton anagDugme;
	// kolekcije koje se koriste za pravljenje radio dugmadi i check box-ova
	private List<String> kljuceviL = new ArrayList<String>();
	private List<String> anagramiL = new ArrayList<String>();
	// katalog se koristi za pronalazenje parova (kljuc, anagram)
	private Map<String, List<String>> katalog = new HashMap<String, List<String>>();
	private int brRedova = 0;
	private int brojac = 0;
	
	public Prozor() {
		super();
		inicijalizuj();
	}
	
	private void inicijalizuj() {
		this.setSize(450, 450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Anagrami");
		Container content = getContentPane();
		
		fc = new JFileChooser(".");
		fc.setFileFilter(new FileFilter() {
			@Override
			public String getDescription(){
				return "Text files (*.txt)";
			}
			@Override
			public boolean accept(File f) {
				return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
			}
		});
		
		content.setLayout(new BorderLayout());
		panelSever = new JPanel();
		panelSever.add((ucitaj = new JButton("Ucitaj")));
		ucitaj.setPreferredSize(new Dimension(80, 30));
		content.add(panelSever, BorderLayout.NORTH);
		ucitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				ucitaj.setEnabled(false);
				anagDugme.setEnabled(true);
				int rez = fc.showOpenDialog(null);
				if(rez == JFileChooser.APPROVE_OPTION){
					Scanner sc = null;
					try {
						sc = new Scanner(fc.getSelectedFile());
						while(sc.hasNextLine())
						{
							String[] par = sc.nextLine().split(":");
							brRedova++;
							if(!katalog.containsKey(par[0].trim()))
							{
								List<String> alista = new ArrayList<String>();
								alista.add(par[1].trim());
								katalog.put(par[0].trim(), alista);
								kljuceviL.add(par[0].trim());
							}
							else
								katalog.get(par[0].trim()).add(par[1].trim());
							anagramiL.add(par[1].trim());
						}
						
						// proizvoljno se mesaju liste kljuceva i anagrama
						Collections.shuffle(kljuceviL);
						Collections.shuffle(anagramiL);
						
						// pravi se niz radio dugmadi za kljuceve i njihove anagrame
						// dimenzije nizova su poznate tek nakon citanja datoteke
						// i popunjavanja kataloga
						kljuceviB = new JRadioButton[katalog.size()];
						anagramiB = new JCheckBox[brRedova];
						ButtonGroup kgr = new ButtonGroup();
						for(int i = 0; i < kljuceviB.length; i++)
						{
							anagLevo.add((kljuceviB[i] = new JRadioButton(kljuceviL.get(i))));
							kgr.add(kljuceviB[i]);
						}
						kljuceviB[0].setSelected(true);
						
						for(int i = 0; i < anagramiB.length; i++)
							anagDesno.add((anagramiB[i] = new JCheckBox(anagramiL.get(i))));
						
						anagLevo.validate();
						anagDesno.validate();
						
					}
					catch (FileNotFoundException e1) {
						return;
					} finally{
						if(sc!=null)
							sc.close();
					}			
				}

			}
		});
		
		panelCentar = new JPanel(new GridLayout(0, 1));
		content.add(panelCentar, BorderLayout.CENTER);
		centarAnag = new JPanel(new GridLayout(1, 2));
		centarAnag.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.blue), 
				"Anagrami", TitledBorder.RIGHT, TitledBorder.TOP));
		anagLevo = new JPanel(new GridLayout(0, 1));
		anagDesno = new JPanel(new GridLayout(0, 1));
		centarAnag.add(anagLevo);
		centarAnag.add(anagDesno);
		panelCentar.add(centarAnag);
		centarRez = new JTextArea("");
		centarRez.setForeground(new Color(0, 100, 0));
		spane = new JScrollPane(centarRez);
		spane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.magenta), 
				"Resenja", TitledBorder.RIGHT, TitledBorder.TOP));
		panelCentar.add(spane);
		
		panelJug = new JPanel();
		content.add(panelJug, BorderLayout.SOUTH);
		panelJug.add((anagDugme = new JButton("Pronadji anagrame")));
		anagDugme.setEnabled(false);
		anagDugme.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				for(JRadioButton kljuc : kljuceviB)
					if(kljuc.isSelected())
					{
						kljuc.setForeground(Color.red);
						List<String> anagrami = katalog.get(kljuc.getText());
						for(String a : anagrami)
							for(JCheckBox box : anagramiB)
							{
								if(box.getText().compareTo(a) == 0)
								{
									// svaki naredni klik na dugme za isto izabrano RadioDugme ne treba da ima efekta
									// jer ce se u suprotnom vise puta prikazati isti par u JTextArea
									if(!box.isSelected()) {
										box.setSelected(true); 	// cekira se dugme 
										brojac++;
										box.setForeground(Color.red);
										centarRez.append(a+ " -> " + kljuc.getText() + "\n");
									}
								}
							}
					}
				if(brojac == brRedova)
					anagDugme.setEnabled(false);
			}
		});
	}
}
