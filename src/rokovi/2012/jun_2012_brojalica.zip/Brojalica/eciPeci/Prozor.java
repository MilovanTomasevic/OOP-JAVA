package eciPeci;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

public class Prozor extends JFrame{
	
	private JButton sledeciBt;
	private JFileChooser fc;
	
	private String[] deca;
	private String[] brojalica;

	private JButton decaBt;
	private JButton brojalicaBt;
	
	private LinkedList<JLabel> decaL = new LinkedList<JLabel>();
	private LinkedList<JTextArea> oblasti = new LinkedList<JTextArea>();
	
	private JPanel decaPanel;
	
	private boolean ukloni = false; // prvi put kada se klikne na "sledeci" ne treba ukloniti
				// nijedno dete jer nije bilo prethodnog razbrajanja
				// a svaki sledeci put se uklanja ono koje je izbaceno u prethodnom krugu
	
	private Iterator<JTextArea> iterOblast;
	private Iterator<JLabel> iterDeca;
		
	public Prozor(String naslov){
		super(naslov);
		
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){
			
		}
		
		Container content = getContentPane();
		
		fc = new JFileChooser(".");
		fc.setFileFilter(new FileFilter() {
			
			@Override
			public String getDescription() {
				return "Text files (*.txt)";
			}
			
			@Override
			public boolean accept(File f) {
				return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
			}
		});
		
		JPanel severPanel = new JPanel();
		Dimension velDugmeta = new Dimension(120, 30);
		decaBt = new JButton("Nadji decu");
		decaBt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int rez = fc.showOpenDialog(null);

				if(rez==JFileChooser.APPROVE_OPTION){
					Scanner sc = null;
					try {
						sc = new Scanner(fc.getSelectedFile());
						if(sc.hasNextLine()){
							deca = sc.nextLine().split(", ");
						
							for(int i=0; i<deca.length; i++){
								JPanel iToDetePanel = new JPanel(new BorderLayout(10,10));
								JLabel iToDeteL = new JLabel(deca[i]);
								iToDeteL.setHorizontalAlignment(JLabel.CENTER);
								iToDetePanel.add(iToDeteL, BorderLayout.NORTH);
								decaL.add(iToDeteL);
								JTextArea iToDeteOblast = new JTextArea();
								iToDeteOblast.setEditable(false);
								JScrollPane iPane = new JScrollPane(iToDeteOblast);
								iToDetePanel.add(iPane, BorderLayout.CENTER);
								oblasti.add(iToDeteOblast);
								
								decaPanel.add(iToDetePanel);	
							}
							decaPanel.validate();	
				
													
							iterOblast = oblasti.iterator(); // od pocetnog deteta (prvog)
									// a posle se o iteratoru vodi racuna gde treba
							iterDeca = decaL.iterator();
							
							// nadjena su deca, pa ako je nadjena i brojalica, razbrojavanje moze da pocne
							if(!brojalicaBt.isEnabled()){
								sledeciBt.setEnabled(true);	
							}
								
							decaBt.setEnabled(false);
													
						}else
							return; // prazan fajl --> nema dece 
					} catch (FileNotFoundException e1) {
						return; // zavrsavamo obradu dogadjaja
					} finally {
						if(sc!=null)
							sc.close();
					}
				}
			}
		});		
		decaBt.setPreferredSize(velDugmeta);
		severPanel.add(decaBt);

		brojalicaBt = new JButton("Nadji brojalicu");
		brojalicaBt.setPreferredSize(velDugmeta);		
		brojalicaBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {

				int rezultat = fc.showOpenDialog(null);
				if(rezultat==JFileChooser.APPROVE_OPTION){
					Scanner sc = null;
						try {
							sc = new Scanner(fc.getSelectedFile());
							if(sc.hasNextLine()){
								String brojalicaStr = sc.nextLine();
								brojalicaStr = brojalicaStr.replaceAll(",", "");								
								brojalicaStr = brojalicaStr.replaceAll("\\.", "");
								brojalica = brojalicaStr.split(" ");
								
								// brojalica je nadjena, a ako su nadjena i deca...
								if(!decaBt.isEnabled())
									sledeciBt.setEnabled(true);
								
								brojalicaBt.setEnabled(false);
							}else
								return; // prazan fajl --> nema brojalice
						} catch (FileNotFoundException e1) {
							return; // zavrsavamo obradu dogadjaja
						} finally {
							if(sc!=null)
								sc.close();
						}
				}
			}
		});

		severPanel.add(brojalicaBt);
		content.add(severPanel, BorderLayout.NORTH);
		
		decaPanel = new JPanel(new GridLayout(1, 0, 10, 10));
		decaPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE));
		
		content.add(decaPanel, BorderLayout.CENTER);
		
		JPanel dugmePanel = new JPanel();
		sledeciBt = new JButton("Sledeci");
		sledeciBt.setEnabled(false);
		sledeciBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(ukloni){ // ovo se nece izvrsiti samo prvi put
					// sad treba da uklonimo tekuce dete iz obe liste i sa panela
					decaPanel.removeAll();
					iterOblast.remove();
					iterDeca.remove();
					
					// prolazimo kroz decu i oblasti koja su preostala i dodamo ih
					Iterator<JLabel> pomIterDeca = decaL.iterator();
					Iterator<JTextArea> pomIterOblasti = oblasti.iterator();
					while(pomIterDeca.hasNext()){
						JPanel tekuceDetePanel = new JPanel(new BorderLayout(10,10));
						tekuceDetePanel.add(pomIterDeca.next(), BorderLayout.NORTH);
						JTextArea tekucaOblast = pomIterOblasti.next();
// umesto starog teksta postavlja se onoliki broj novih redova koliko ih je imalo u starom tekstu.
						int brRedovaStarogTeksta = tekucaOblast.getText().split("\n").length;
						String noviText = "";
						for(int i=0; i<brRedovaStarogTeksta; i++)
							noviText+="\n";
						tekucaOblast.setText(noviText);
						
						tekuceDetePanel.add(tekucaOblast, BorderLayout.CENTER);
						decaPanel.add(tekuceDetePanel);
					}
									
					decaPanel.validate();
					decaPanel.repaint();
					
					// ako je ostao tacno jedan, on je pobednik
					if(decaL.size()==1){
						sledeciBt.setEnabled(false);
						decaL.getFirst().setForeground(Color.GREEN);
						oblasti.getFirst().setText("POBEDNIK!");
						return;
					}				
				}
				
				ukloni = true;				
				
				JLabel poslednji = null;
				for(int rec = 0; rec<brojalica.length; rec++){
					// ako smo dosli do kraja, uzimamo novi iterator
					if(!iterOblast.hasNext()){
						iterOblast = oblasti.iterator();
						iterDeca = decaL.iterator(); // krecemo se i kroz labele, da i njih mozemo da uklanjamo
					}
					iterOblast.next().append(brojalica[rec]+"\n");
					poslednji = iterDeca.next(); // pomerimo se i kroz labele
				}
				poslednji.setForeground(Color.RED);
			}	
		});
		dugmePanel.add(sledeciBt);
		
		content.add(dugmePanel, BorderLayout.SOUTH);
	}
}