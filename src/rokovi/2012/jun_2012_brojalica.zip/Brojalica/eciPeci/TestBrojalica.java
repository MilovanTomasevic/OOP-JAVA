package eciPeci;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class TestBrojalica {

	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				createGUI();
			}
		});
	}
	
	public static void createGUI(){
		Prozor prozor = new Prozor("Brojalica");
		prozor.setSize(600, 400);
		prozor.setLocationRelativeTo(null);
		prozor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		prozor.setVisible(true);
	}

}
