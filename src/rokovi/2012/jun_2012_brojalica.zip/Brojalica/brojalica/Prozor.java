package brojalica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

public class Prozor extends JFrame {
	
	private JButton decaBt;
	private JButton brojalicaBt;
	private JButton sledeciBt;
	private Vector<JLabel> decaL;
	private Vector<JTextArea> oblasti;
	private String[] brojalica;
	private int razbrajac=0;
	private boolean ukloni = false;
	
	public Prozor(String naslov){

		super(naslov);

		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){
			
		}
		
		Container content=getContentPane();
		
		JPanel gorePanel=new JPanel();
		decaBt=new JButton("Nadji decu");
		decaBt.setPreferredSize(new Dimension(200,30));
		
		final JFileChooser fc=new JFileChooser(".");
		fc.setFileFilter(new FileFilter() {
			
			@Override
			public String getDescription() {
				return "Text files (*.txt)";
			}
			
			@Override
			public boolean accept(File f) {
				return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
			}
		}); 
		
		final JPanel decaPanel=new JPanel(new GridLayout(1, 0, 10, 10));
		decaPanel.setBorder(BorderFactory.createLineBorder(Color.black));	
		content.add(decaPanel,BorderLayout.CENTER);		
			
		decaBt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int rez=fc.showOpenDialog(decaBt);
				if(rez==JFileChooser.APPROVE_OPTION){
					File f=fc.getSelectedFile();	
					try {
						Scanner sc=new Scanner(f);
						String s=sc.nextLine();
						String[] deca=s.split(", ");

						decaL=new Vector<JLabel>(deca.length);
						oblasti=new Vector<JTextArea>(deca.length);
						for(int i=0;i<deca.length;i++)
						{
							JPanel iToDetePanel = new JPanel(new BorderLayout(10,10));
							JLabel iToDeteL=new JLabel(deca[i]);
							iToDeteL.setHorizontalAlignment(JLabel.CENTER);
							iToDetePanel.add(iToDeteL, BorderLayout.NORTH);
							decaL.add(iToDeteL);

							JTextArea iToDeteOblast=new JTextArea();
							iToDeteOblast.setEditable(false);
							JScrollPane iPane = new JScrollPane(iToDeteOblast);
							iToDetePanel.add(iPane, BorderLayout.CENTER);
							oblasti.add(iToDeteOblast);
							
							decaPanel.add(iToDetePanel);	
						}

						decaPanel.validate();

						if(brojalicaBt.isEnabled()==false) sledeciBt.setEnabled(true);
						decaBt.setEnabled(false);
					} catch (FileNotFoundException e) {

					}
				}
			}
		});
		
		gorePanel.add(decaBt);
		brojalicaBt=new JButton("Nadji brojalicu");
		brojalicaBt.setPreferredSize(new Dimension(200,30));
		brojalicaBt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int rez=fc.showOpenDialog(brojalicaBt);
				if(rez==JFileChooser.APPROVE_OPTION){
					File f=fc.getSelectedFile();	
					try {
						Scanner sc=new Scanner(f);
						brojalica=sc.nextLine().split(",? |\\.");  // delimiter je opciona zapeta za kojom sledi blanko ili tacka								
						if(decaBt.isEnabled()==false) sledeciBt.setEnabled(true);
						brojalicaBt.setEnabled(false);
					}
					catch (FileNotFoundException e) {
						
					}
				}
			}
		});
		
		gorePanel.add(brojalicaBt);
		content.add(gorePanel,BorderLayout.NORTH);

		JPanel dolePanel=new JPanel();
		sledeciBt=new JButton("Sledeci");
		sledeciBt.setPreferredSize(new Dimension(150,30));
		sledeciBt.setEnabled(false);
		sledeciBt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
											
				if(ukloni){ // nije prvi krug, treba ukloniti dete koje je ispalo u prethodnom krugu
					decaPanel.remove(razbrajac);
					oblasti.remove(razbrajac);
					decaL.remove(razbrajac);			
					decaPanel.validate(); 		
					decaPanel.repaint();
					
					// "brisanje" reci od ranije
					for(JTextArea ta: oblasti){
						// umesto starog teksta postavlja se onoliki broj novih redova koliko ih je imalo u starom tekstu.
						int brRedovaStarogTeksta = ta.getText().split("\n").length;
						String noviText = "";
						for(int j=0; j<brRedovaStarogTeksta; j++)
							noviText+="\n";
						ta.setText(noviText);
					}
				}
				
				int n=decaL.size();
				int trenutni = razbrajac%n;
				Vector<String> rez = new Vector<String>();
				
				/* formiranje stringa sa recima koje se pridruzuju svakom detetu */
				for(int i = 0; i<n; i++)
					rez.add("");							
				for(String rec: brojalica){
					rez.set(trenutni, rez.get(trenutni)+rec+"\n");
					trenutni = (trenutni+1)%n;
				}
				
				trenutni = (trenutni + n - 1)%n; 	
				int i = 0;
				for(JTextArea ta: oblasti)
					// nadoveze se tekst za tekuci krug razbrajanja
					ta.append(rez.get(i++));	
				
				decaL.get(trenutni).setForeground(Color.RED);
	
				razbrajac = trenutni%n; 				
				ukloni = true;
				
				// kraj
				if(decaL.size()==1){
					decaL.firstElement().setForeground(Color.GREEN);
					oblasti.firstElement().setText("POBEDNIK!");
					sledeciBt.setEnabled(false);
					return; 
				}	
			}
		});

		dolePanel.add(sledeciBt);
		content.add(dolePanel,BorderLayout.SOUTH);		
	}
}
