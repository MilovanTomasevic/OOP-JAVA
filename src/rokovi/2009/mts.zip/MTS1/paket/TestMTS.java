package paket;

import java.util.Scanner;
import java.util.Random;

public class TestMTS {

	public static void main(String[] args) {
		
		
		/* Unosi se broj korisnika, pa se onda kreiraju ti korisnici i smestaju u niz.
		 * Onda se 5 puta slucajno bira neki korisnik iz niza ispisuju podaci o njemu
		 * ako je prepaid nudi se dopuna kredita, sms ili razgovor
		 * ako je postpaid nudi se sms ili razgovor
		 * obavi se usluga i ispisu se azurirani podaci o korisniku
		 */
		
		
		System.out.println("Unesite broj korisnika");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		Korisnik korisnici[]=new Korisnik[n];
		
		for(int i=0; i<n; i++){
			String broj=null;
			for(; ;){
				System.out.println("Unesite telefonski broj korisnika: ");
				broj=sc.next();
				if(Korisnik.validan(broj))
					break;
				System.out.println("Nekorektan unos, pokusajte ponovo.");
	
			}
		
			
			
			System.out.println("Unesite 1 za prepaid korisnika, 2 za postpaid korisnika");
			int izbor=sc.nextInt();
			
			switch(izbor){
				case 1:
					System.out.println("Unesite kredit: ");
					int kredit=sc.nextInt();
					String ff[]=new String[3];
					for(int j=0; j<ff.length; j++){
						System.out.println("Unesite " + (j+1) + ". f&f broj: ");
						ff[j]=sc.next();
						if(!Korisnik.validan(ff[j])){
							System.out.println("Broj nije validan ili ne pripada mrezi korisnika");
							j--;
						}
					}
					korisnici[i]=new Prepaid(broj, kredit, ff);
					break;
				case 2:
					korisnici[i]=new Postpaid(broj);
					break;
				default:
					System.out.println("Neispravna opcija.");
				    i--;
					break;
			}
			
		}
			
		Random random=new Random();
		for(int i=0; i<5; i++){
			Korisnik izabrani=korisnici[random.nextInt(korisnici.length)];
			System.out.println(izabrani);
			
			if(izabrani instanceof Prepaid){
				System.out.println("Unesite vrstu usluge: \"dopuna\", \"sms\" ili \"razgovor\"");
				String izbor=sc.next();
				if(izbor.equalsIgnoreCase("dopuna")){
					System.out.println("Unesite sumu:");
					((Prepaid)izabrani).dopuni_kredit(sc.nextInt());
					System.out.println("Nakon usluge: " + izabrani);
					
				}else if(izbor.equalsIgnoreCase("sms")){
					izabrani.azuriraj_racun_SMS();
					System.out.println("Nakon usluge: " + izabrani);
					
				}else if(izbor.equalsIgnoreCase("razgovor")){
					System.out.println("Unesite broj koji se poziva:");
					String broj=sc.next();
					System.out.println("Unesite trajanje razgovora: sat minut sekunda");
					int sat=sc.nextInt();
					int minut=sc.nextInt();
					int sekunda=sc.nextInt();
					if(!Vreme.validan(sat, minut, sekunda)){
						System.out.println("Neispravno trajanje razgovora");
						i--;
						continue;
					}
					izabrani.azuriraj_racun_razgovor(new Razgovor(broj, new Vreme(sat, minut, sekunda)));
					System.out.println("Nakon usluge: " + izabrani);	
				}else{
					System.out.println("Pogresna opcija");
					i--;
					continue;
				}
			}else{
				System.out.println("Unesite sms ili razgovor");
				String izbor=sc.next();
				if(izbor.equalsIgnoreCase("sms")){
					izabrani.azuriraj_racun_SMS();
					System.out.println("Nakon usluge: " + izabrani);
				}else if(izbor.equalsIgnoreCase("razgovor")){
					System.out.println("Unesite broj koji se poziva:");
					String broj=sc.next();
					System.out.println("Unesite trajanje razgovora: sat minut sekunda");
					int sat=sc.nextInt();
					int minut=sc.nextInt();
					int sekunda=sc.nextInt();
					if(!Vreme.validan(sat, minut, sekunda)){
						System.out.println("Neispravno trajanje razgovora");
						i--;
						continue;
					}
					izabrani.azuriraj_racun_razgovor(new Razgovor(broj, new Vreme(sat, minut, sekunda)));
					System.out.println("Nakon usluge: " + izabrani);	
					
				}else{
					System.out.println("Pogresna opcija");
					i--;
				}
			
				
			}
			
		}

	}

}
