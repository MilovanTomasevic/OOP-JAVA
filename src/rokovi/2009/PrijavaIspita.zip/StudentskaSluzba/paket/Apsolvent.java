package paket;

public class Apsolvent extends Student{
	private static String apsrokovi[]={"mart","april","novembar","decembar"};
	private static Datum krajnjiRokAps[]={new Datum(1,3,2009), new Datum(1,4,2009),
		                                  new Datum(1,11,2009), new Datum(1,12,2009)};
	
	
	
	public Apsolvent(String ime, String prezime, String smer, final Datum d, final Ispit i){
		super("apsolvent", ime, prezime, smer, d, i);
	}
	
	public Apsolvent(final Apsolvent a){
		super("apsolvent", a.getIme(), a.getPrezime(), a.getSmer(), a.getDatum(), a.getIspit());
	}
	
	public int uplata(){
		return 300;
	}
	
	public boolean moze(String rok){
		
		/* 
		 * samo treba proveriti da li je prijavio ispit (sve je odslusao)
		 * do krajnjeg datuma za taj rok, a ima prava da polaze u svakom roku
		 */
		
		
		/* ako ga je prijavio za apsolventski rok pre isteka za njegovo prijavljivanje */
		int i;
		for(i=0; i<apsrokovi.length; i++)
			if(rok.equals(apsrokovi[i]) && getDatum().pre(krajnjiRokAps[i]))
				return true;
		
		

		
		/* gledamo da nije u pitanju neapsolventski rok */
		String rokovi[]=getRokovi();
		for(i=0; i<rokovi.length; i++)
			if(rok.equals(rokovi[i]) && getDatum().pre(getKrajnjiRok(i)))
				return true;
		
		
		
		return false;
		
	}

}
