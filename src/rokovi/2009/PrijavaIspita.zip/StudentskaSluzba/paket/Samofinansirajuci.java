package paket;

public class Samofinansirajuci extends Student{

	private int godinaStudija;
	
	public Samofinansirajuci(String ime, String prezime, String smer, int godinaStudija, final Datum d, final Ispit i){
		super("samofinansirajuci", ime, prezime, smer, d, i);
		this.godinaStudija=godinaStudija;
	}

	public Samofinansirajuci(final Samofinansirajuci s){
		super("samofinansirajuci", s.getIme(), s.getPrezime(), s.getSmer(), s.getDatum(), s.getIspit());
		godinaStudija=s.godinaStudija;
	}
	
	public boolean moze(String rok){
		String rokovi[]=Student.getRokovi();
	
		
		/* gledamo da li on moze da polaze u tom roku */
		for(int i=0; i<rokovi.length; i++)
			if(rok.equals(rokovi[i]) && getDatum().pre(getKrajnjiRok(i)) && godinaStudija>getIspit().getGodina())
				return true;
		
		return false;
			
	}
	
	public int uplata(){
		return 300;
	}
	
	public String toString(){
		return super.toString() + "\ngodina studija studenta: " + godinaStudija;
	}
	

}
