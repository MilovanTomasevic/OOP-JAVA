package paket;

public class Ispit {
	
	private String ispit;
	private int godina;

	
	public Ispit(String ispit, int godina){
		this.ispit=ispit;
		this.godina=godina;
	}
	
	public Ispit(final Ispit i){
		this(i.ispit, i.godina);
	}
	
	public String getIspit(){
		return ispit;
	}
	
	public int getGodina(){
		return godina;
	}
	
	
	public String toString(){
		return ispit + ", god. studija: " + godina;
	}

}
