package paket;

public abstract class Student {
	
	private static String rokovi[]={"januar", "februar" , "jun", "septembar", "oktobar"};
	private static Datum krajnjiRok[]={new Datum(1,1,2009), new Datum(1,2,2009), new Datum(1,6,2009),
		                               new Datum(1,9,2009), new Datum(1,10,2009)};
	
	private String ime;
	private String prezime;
	private String smer;
	
	private Datum datum;
	private Ispit ispit;
	
	private String kategorija;
	
	public Student(String kategorija, String ime, String prezime, String smer, final Datum datum, final Ispit ispit){
		this.kategorija=kategorija;
		this.ime=ime;
		this.prezime=prezime;
		this.smer=smer;
		this.datum=new Datum(datum);
		this.ispit=new Ispit(ispit);
	}
	
	public Student(final Student s){
		this(s.kategorija, s.ime, s.prezime, s.smer, s.datum, s.ispit);
	}
	
	
	
	public abstract int uplata();
	public abstract boolean moze(String rok);
	
	public String getIme(){
		return ime;
	}
	
	public String getPrezime(){
		return prezime;
	}
	
	
	public String getSmer(){
		return smer;
	}
	
	public Datum getDatum(){
		return datum;
	}
	
	public Ispit getIspit(){
		return ispit;
	}
	
	public static String[] getRokovi(){
		return rokovi;
	}
	
	public static Datum getKrajnjiRok(int i){
		return krajnjiRok[i];
	}
	
	public String toString(){
		return kategorija + " student: " + ime + " " + prezime + ", smer: " + smer +
		      ", datum prijave: " + datum + ", ispit: " + ispit;
	}
}
