package paket;

import java.util.Scanner;

public class Test {


	public static void main(String[] args) {
		
        Scanner sc=new Scanner(System.in);        
       
        System.out.println("Unesite broj studentskih prijava: ");
        int n=sc.nextInt();
        
        Student studenti[]=new Student[n];
        
        for(int i=0; i<n; i++){
        	System.out.println("Ime " + (i+1) + ". studenta: ");
        	String ime=sc.next();
        	System.out.println("Prezime: ");
        	String prezime=sc.next();
        	System.out.println("Smer: ");
        	String smer=sc.next();
        	
        	
    		Datum datum=null;
        	while(datum==null){  /* ponavlja se dok se ne unese ispravan datum */
        	
        		System.out.println("Datum prijave, oblika dd.mm.gggg.");
        		String datumS=sc.next();
        		
        		datum=Datum.string2datum(datumS);
        	}
        	
        	

        	System.out.println("Unesite ime ispita: ");
        	String ispitS=sc.next();
        	
        	System.out.println("Unesite godinu studija na kojoj se slusa ispit: ");
        	int godinaStudija=sc.nextInt();
        	
        	Ispit ispit=new Ispit(ispitS ,godinaStudija);
        	
        	System.out.println("Unesite: \n");
        	System.out.println("\t\"redovni\" - za redovnog studenta");
        	System.out.println("\t\"samofinansirajuci\" - za samofinansirajuceg i ");
        	System.out.println("\t\"apsolvent\" - za apsolventa");
        	
        	String kategorija=sc.next();
        	
        	if(kategorija.equalsIgnoreCase("redovni")){
        		System.out.println("Unesite godinu studija studenta: ");
        		int godStud=sc.nextInt();
        		System.out.println("Unesite koji put polaze ispit koji prijavljuje: ");
        		int kojiPut=sc.nextInt();
        		studenti[i]=new Redovni(ime,prezime,smer,godStud,datum,ispit,kojiPut);
        	}else if(kategorija.equalsIgnoreCase("samofinansirajuci")){
        		System.out.println("Unesite godinu studija studenta: ");
        		int godStud=sc.nextInt();
        		studenti[i]=new Samofinansirajuci(ime,prezime,smer,godStud,datum, ispit);
        	}else if(kategorija.equalsIgnoreCase("apsolvent")){
        		studenti[i]=new Apsolvent(ime,prezime,smer, datum, ispit);
        	}else{
        		System.out.println("Pogresan izbor kategorije");
        	    i--;
        	} 	
        }
        
        System.out.println("Unesite ispitni rok za koji je prijava u toku: ");
        String tekuciRok=sc.next();
        
        /* Za prijave koje nisu prosle, ispisujemo da nisu prosle, a za one koje jesu, ispisujemo koliko novca student treba da uplati */
        for(int i=0; i<studenti.length; i++)
        	if(studenti[i].moze(tekuciRok))
        		System.out.println(studenti[i] + ", uplatiti: " + studenti[i].uplata() + " dinara.");
        	else
        		System.out.println(studenti[i] + ", PRIJAVA NIJE PROSLA.");
		

	}

}
