package paket;

public class Redovni extends Student{

  private int godinaStudija;
	private int kojiPut;
	
	public Redovni(String ime, String prezime, String smer, int godinaStudija, final Datum d, final Ispit i, int kojiPut){
		super("redovni", ime, prezime, smer, d, i);
		this.godinaStudija=godinaStudija;
		this.kojiPut=kojiPut;
	}
	
	public Redovni(final Redovni r){
		super("redovni", r.getIme(), r.getPrezime(), r.getSmer(), r.getDatum(), r.getIspit());
		godinaStudija=r.godinaStudija;
		kojiPut=r.kojiPut;
	}
	
	public int uplata(){
		if(kojiPut<3)
			return 0;
		return 300;
	}
	
	public boolean moze(String rok){
		String rokovi[]=Student.getRokovi();
		
		/* gledamo da li on moze da polaze u tom roku */
		for(int i=0; i<rokovi.length; i++)
			if(rok.equals(rokovi[i]) && getDatum().pre(getKrajnjiRok(i)) && godinaStudija>getIspit().getGodina())
				return true;
			
		return false;


	}
	
	
	
	public String toString(){
		return super.toString() + ", ispit polaze: " + kojiPut + ". put" +
		"\ngodina studija studenta: " + godinaStudija;
	}
}
