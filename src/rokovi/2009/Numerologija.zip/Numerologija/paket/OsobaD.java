package paket;

public class OsobaD extends Osoba{
	
	private Datum datum;
	
	public OsobaD(String ime, String prezime, String adresa, Datum d){
		super(ime, prezime, adresa);
		datum=new Datum(d);
	}
	
	public OsobaD(final OsobaD o){
		super(o.getIme(),o.getPrezime(),o.getAdresa());
		datum=new Datum(o.datum);
	}
	
	
	
	public int numeroloskiBroj(){
		int suma=zbircifara(datum.getDan())
		                    +zbircifara(datum.getMesec())
		                    +zbircifara(datum.getGodina());
		                    
		while(suma>10)
			suma=zbircifara(suma);
		
		return suma;
	}
	
	public String metabolizam(final Datum d){
		int danR=datum.getDan();
		int mesecR=datum.getMesec();
		int dan=d.getDan();
		int mesec=d.getMesec();
		
		String mesecRS= (mesecR<10)? "0"+mesecR: ""+mesecR;
		String mesecS=(mesec<10)? "0"+mesec: ""+mesec;
		
		String datumRS=danR+mesecRS+datum.getGodina();
		String dS=dan+mesecS+d.getGodina();
		
		return String.valueOf(Integer.parseInt(datumRS) + 
		       Integer.parseInt(dS));
	}
	
	public String toString(){
		return super.toString() + "; numeroloski broj: " +
		     numeroloskiBroj();
	}

}
