package paket;

import javax.swing.JApplet;
import javax.swing.SwingUtilities;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.util.Vector;

public class Aplet extends JApplet{

	public void init(){
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				createGUI();
			}
		});
	}
	
	
	
	
	private void createGUI(){
		Container content=getContentPane();
		content.setLayout(new GridLayout(0,2));
		JPanel panel1=new JPanel(new GridLayout(0,1));
		panel1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(Color.BLUE,Color.CYAN),"boja"));
		ButtonGroup group=new ButtonGroup();
		for(int i=0; i<4; i++){
			panel1.add(boje[i]=new JRadioButton(Boja.values()[i].name()));
			boje[i].setForeground((Boja.values()[i].equals(Boja.TREF) || Boja.values()[i].equals(Boja.PIK))? Color.BLACK : Color.RED); 
			group.add(boje[i]);
		}
		boje[0].setSelected(true);
		
		content.add(panel1);
		
		JPanel panel2=new JPanel(new FlowLayout(FlowLayout.LEFT,5,5));
		panel2.add(new JLabel("vrednost"));
		vrednost=new JTextField(2);
		panel2.add(vrednost);
		content.add(panel2);
		
		
		content.add(panelRez);
		
		JPanel panel3=new JPanel(new FlowLayout(FlowLayout.LEFT,5,5));
		unesi=new JButton("Unesi");
		unesi.setPreferredSize(new Dimension(80,20));
		unesi.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Boja boja=null;
				for(int i=0; i<boje.length; i++)
					if(boje[i].isSelected()){
						boja=Boja.values()[i];
						break;
					}
				int vr=0;
				try{
				  vr=Integer.parseInt(vrednost.getText());
				}catch(NumberFormatException nfe){
					vrednost.setText("GR!");
					return;
				}
				if(vr<1 || vr>=15){
					vrednost.setText("GR!");
					return;
				}
				Karta karta=null;
				karte.add(karta=new Karta(boja, vr));
				
				JCheckBox cbox;
				panelRez.add(cbox=new JCheckBox(boja +" " + karta.getVrednost()));
				cbox.setForeground((boja.equals(Boja.TREF)|| boja.equals(Boja.PIK))?
				Color.BLACK : Color.RED);
				cbox.addMouseListener(new MouseAdapter(){
					public void mouseEntered(MouseEvent e){
						Object source=e.getSource();
						((JCheckBox)source).setEnabled(false);
						
					}
					
					public void mouseExited(MouseEvent e){
						Object source=e.getSource();
						((JCheckBox)source).setEnabled(true);
					}
				}
				
						);
				checkBoxovi.add(cbox);
				
				// Ovo se zove kada je promenjeno nesto od komponenata, a 
				// vec je prikazano!!!
				validate();
				
			}
		});
		content.add(panel3);
		panel3.add(unesi);
		
		
		JPanel panel4=new JPanel(new GridLayout(0,1));
		panel4.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(Color.BLUE,Color.CYAN),"boja"));
		ButtonGroup group1=new ButtonGroup();
		for(int i=0; i<4; i++){
			panel4.add(trazenaBoja[i]=new JRadioButton(Boja.values()[i].name()));
			trazenaBoja[i].setForeground((Boja.values()[i].equals(Boja.TREF) || Boja.values()[i].equals(Boja.PIK))? Color.BLACK : Color.RED); 
			group1.add(trazenaBoja[i]);
		}
		trazenaBoja[0].setSelected(true);
		
		content.add(panel4);
		
		JPanel panel5=new JPanel(new FlowLayout(FlowLayout.LEFT,5,5));
		prikazi.setPreferredSize(new Dimension(80,20));
		content.add(panel5);
		panel5.add(prikazi);
		prikazi.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				int i;
				for(i=0; i<trazenaBoja.length; i++)
					if(trazenaBoja[i].isSelected())
						break;
				
				for(JCheckBox checkBox:checkBoxovi){
					if(checkBox.getText().startsWith(trazenaBoja[i].getText()))
						checkBox.setSelected(true);
					else
						checkBox.setSelected(false);
				}
				
			}
		});
	}
	
	
	 

	private JRadioButton[] boje=new JRadioButton[4];
	private JTextField vrednost;
	private JButton unesi;
	
	private Vector<Karta> karte=new Vector<Karta>();
	private Vector<JCheckBox> checkBoxovi=new Vector<JCheckBox>();
	private JPanel panelRez=new JPanel(new GridLayout(0,1));
	
	private JRadioButton[] trazenaBoja=new JRadioButton[4];
	private JButton prikazi=new JButton("Prikazi");
}
