package paket;

public enum Boja {
	TREF, HERC, KARO, PIK
}
