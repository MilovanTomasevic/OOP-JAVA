package paket;

public class Karta {

	public Karta(Boja boja, int vrednost){
		this.boja=boja;
		if(vrednost>=2 && vrednost <=10)
			this.vrednost=Vrednost.values()[vrednost-2];
		else if(vrednost==1 || vrednost==11)
			this.vrednost=Vrednost.values()[12];
		else 
			this.vrednost=Vrednost.values()[vrednost-3];
		
	}
	
	public Vrednost getVrednost(){
		return vrednost;
	}
	
	private Boja boja;
	private Vrednost vrednost;
}
