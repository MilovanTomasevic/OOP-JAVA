package paket;

public class Osoba implements Comparable<Osoba> {

	public Osoba(String ime, String prezime, int godiste){
		this.ime=ime;
		this.prezime=prezime;
		this.godiste=godiste;
	}
	
	public int compareTo(Osoba osoba){
		if(izborLeksikografski){
			int rezultat=prezime.compareTo(osoba.prezime);
			if(rezultat==0)
				return ime.compareTo(osoba.ime);
			return rezultat;
		}
		else
			return osoba.godiste-godiste;
	}
	
	
	public String getIme(){
		return ime;
	}
	
	public String getPrezime(){
		return prezime;
	}
	
	public int getGodiste(){
		return godiste;
	}
	
	public static void setIzborLeksikografski(boolean izbor){
		izborLeksikografski=izbor;
	}
	
	private String ime;
	private String prezime;
	private int godiste;
	
	private static boolean izborLeksikografski=true;
}
