package paket;

import javax.swing.JApplet;
import javax.swing.SwingUtilities;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Vector;
import java.util.Collections;

import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;

//***************************
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
//****************************

public class Aplet extends JApplet{

	public void init(){
		SwingUtilities.invokeLater(
				new Runnable(){ 
					public void run(){
						createGUI();
					}
				});
	}
	
	private void createGUI(){
		setSize(400,400);
		Container content=getContentPane();
		content.setLayout(new GridLayout(0,1));
		JPanel panel1=new JPanel(new FlowLayout(FlowLayout.LEFT,5,0));
		JPanel panel11=new JPanel();
		JLabel imeLabel=new JLabel("ime i prezime:");
		panel11.add(imeLabel);
		panel11.add(ime);
		ime.setPreferredSize(new Dimension(150,25));
		panel1.add(panel11);
		
		JPanel panel12=new JPanel();
		JLabel godisteLabel=new JLabel("godiste:");
		panel12.add(godisteLabel);
		panel12.add(godiste);
		godiste.setPreferredSize(new Dimension(50,25));
		panel1.add(panel12);

		content.add(panel1);
		
		JPanel panel2=new JPanel(new FlowLayout(FlowLayout.CENTER,5,5));
		
		panel2.add(unesi=new JButton("Unesi"));
		unesi.setPreferredSize(new Dimension(80,20));
		unesi.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String imeprezimeS=ime.getText();
				String imeS=null;
				String prezimeS=null;
				// rezdvajamo ime i prezime
				int belina=imeprezimeS.indexOf(" ");
				if(belina==-1){
					ime.setText("Neispravan unos");
					return;
				}
				else{
					imeS=imeprezimeS.substring(0,belina);
					prezimeS=imeprezimeS.substring(belina+1).trim();
				}
				int god=0;
				try{
					 god=Integer.parseInt(godiste.getText());
				}catch(NumberFormatException nfe){
					ime.setText("Neispravno godiste!");
					return;
				}
				
				osobe.add(new Osoba(imeS,prezimeS,god));
				
				
			}
		});
		
		
		panel2.add(ponisti=new JButton("Ponisti"));
		ponisti.setPreferredSize(new Dimension(80,20));	
		ponisti.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ime.setText("");
				godiste.setText("");
			}
		});
		
		content.add(panel2);
		
		
		JPanel panel3=new JPanel(new GridLayout(0,1));
		panel3.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(Color.blue,Color.cyan),"sortiranje"));
		ButtonGroup group=new ButtonGroup();
		panel3.add(sortiranjeLeksikografski=new JRadioButton("po prezimenu i imenu",true));
		panel3.add(sortiranjeNumericki=new JRadioButton("po godinama starosti, rastuce"));
		group.add(sortiranjeLeksikografski);
		group.add(sortiranjeNumericki);
		sortiranjeLeksikografski.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Osoba.setIzborLeksikografski(true);
			}
		});
		
		sortiranjeNumericki.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Osoba.setIzborLeksikografski(false);
			}
		});
		
		
		content.add(panel3);
		
		JPanel panelDugmeSort=new JPanel();
		content.add(panelDugmeSort);
		panelDugmeSort.add( sortiraj = new JButton("Sortiraj i ispisi rezultat"));
		sortiraj.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(osobe.size()!=0){
					Collections.sort(osobe);
					imePrezime.setText(osobe.firstElement().getIme()+" " + 
									   osobe.firstElement().getPrezime());
					god.setText(String.valueOf(osobe.firstElement().getGodiste()));
					
					StringBuffer str=new StringBuffer();
					for(Osoba osoba: osobe){
						str.append(osoba.getIme()+ " " + osoba.getPrezime() + " " + osoba.getGodiste()+"\n");
					}
					izlaz.setText(str.toString());
					
				}
				else imePrezime.setText("Prazna kolekcija!");
			}
		});
		
		
		JPanel panel4=new JPanel(new FlowLayout(FlowLayout.LEFT,5,5));
		JPanel panel41=new JPanel();
		panel41.add(new JLabel("ime i prezime:"));
		imePrezime.setSize(new Dimension(200,20));
		imePrezime.setPreferredSize(new Dimension(150,25));
		imePrezime.setEditable(false);
		panel41.add(imePrezime);
		imePrezime.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e){
				stari=imePrezime.getFont();
				imePrezime.setFont(new Font(stari.getFamily(),stari.getStyle(),stari.getSize()+5));
				imePrezime.setForeground(Color.RED);
			}		
			public void mouseExited(MouseEvent e){
				imePrezime.setFont(stari);
				imePrezime.setForeground(Color.BLACK);			
			}
			
			private Font stari;
			
		});
		panel4.add(panel41);
		
		JPanel panel42=new JPanel();
		panel42.add(new JLabel("godiste:"));
		panel42.add(god);
		god.setPreferredSize(new Dimension(80,20));
		god.setEditable(false);
		god.setPreferredSize(new Dimension(50,25));
		god.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e){
				stari=god.getFont();
				god.setFont(new Font(stari.getFamily(),stari.getStyle(),stari.getSize()+5));
				god.setForeground(Color.RED);
			}
			
			public void mouseExited(MouseEvent e){
				god.setFont(stari);
				god.setForeground(Color.BLACK);
			}
			
			private Font stari;
		});
		panel4.add(panel42);
		
		content.add(panel4);	
		////////////////////////////////////////////
		JScrollPane panel5=new JScrollPane(izlaz);
		content.add(panel5);
		///////////////////////////////////////////

	}
	
	private JTextField ime=new JTextField();
	private JTextField godiste=new JTextField();
	
	private JButton unesi;
	private JButton ponisti;
	
	private JRadioButton sortiranjeLeksikografski;
	private JRadioButton sortiranjeNumericki;
	
	private JTextField imePrezime=new JTextField();
	private JTextField god=new JTextField();
	
	private JButton sortiraj;
	
	private Vector<Osoba> osobe=new Vector<Osoba>();
	
	
	//////////*****************//////////////
	private JTextArea izlaz=new JTextArea();
	
	
}
