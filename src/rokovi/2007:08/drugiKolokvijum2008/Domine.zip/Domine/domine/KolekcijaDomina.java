package domine;

import java.util.*;

public class KolekcijaDomina 
{
	private Vector<Domina> domine = new Vector<Domina>();
	
	public KolekcijaDomina()
	{
		for(int i = 0; i <= 6; i++)
			for(int j = i; j <= 6; j++)
				domine.add(new Domina(i, j));
	}
	
	public void promesaj()
	{
		Collections.shuffle(domine);
	}
	
	public int velicina()
	{
		return domine.size();
	}
	
	public Domina vratiDominu(int i)
	{
		return domine.get(i);
	}
	
	// Izbaci iz kolekcije dominu sa datom kombinacijom brojeva
	public boolean ukloni(Domina domina)
	{
		Iterator<Domina> iter = domine.iterator();
		while(iter.hasNext())
		{
			if(iter.next().jednake(domina))
			{
				iter.remove();
				return true;
			}
		}
		return false;

	}
	
	
}
