package domine;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class DomineAplet extends JApplet
{
	static final long serialVersionUID = 1;
	
	final static int za_izbor = 5;
	private int brojac = 0;
	private Vector<JButton> dugmeta_izbor = new Vector<JButton>();
	private Vector<Domina> domine_izbor = new Vector<Domina>();
	private KolekcijaDomina kolekcija_domina = new KolekcijaDomina();
	private JButton izabrano_dugme;
	private Domina izabrana_domina;
		
	private JPanel panel_unos;
	private JTextField unos_a, unos_b;
	private JLabel labela_poruka;
	
	private JPanel panel_izbor;
	private JButton izaberi;
	
	private JPanel panel_ispis;
	
	private JPanel panel_rezultat;
	private JButton ukupno_tacaka;
	private JTextField polje_rezultat;
	
	public void init()
	{
		setSize(450, 450);
		setLayout(new GridLayout(0,1)); 
		
		kolekcija_domina.promesaj();
		for(int i=0; i<kolekcija_domina.velicina(); i++)
			System.out.println(kolekcija_domina.vratiDominu(i));
		System.out.println();
		
		panel_unos = new JPanel(new GridLayout(0,1));
		panel_unos.setBorder(BorderFactory.createTitledBorder(
							BorderFactory.createEtchedBorder(Color.BLUE, Color.CYAN),
											"Izbor domina"));
		
				
		JPanel izbor1 = new JPanel();
		JLabel labela_a = new JLabel("Broj tacaka na jednoj polovini domine:");
		unos_a = new JTextField("");
		unos_a.setPreferredSize(new Dimension(40, 20));
		izbor1.add(labela_a);
		izbor1.add(unos_a);
		
		JPanel izbor2 = new JPanel();
		JLabel labela_b = new JLabel("Broj tacaka na drugoj polovini domine:");
		unos_b = new JTextField("");
		unos_b.setPreferredSize(new Dimension(40, 20));
		izbor2.add(labela_b);
		izbor2.add(unos_b);
		
		panel_unos.add(izbor1);
		panel_unos.add(izbor2);
		
		add(panel_unos);
		
		panel_izbor = new JPanel(new GridLayout(0, 1));
		
		labela_poruka = new JLabel("poruka");
		labela_poruka.setHorizontalAlignment(SwingConstants.CENTER);
		labela_poruka.setForeground(Color.RED);
		panel_izbor.add(labela_poruka);
				
		JPanel panel_izaberi = new JPanel();
		izaberi = new JButton("Izaberi");
		panel_izaberi.add(izaberi);
		panel_izbor.add(panel_izaberi);
		add(panel_izbor);
		
		panel_ispis = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 20));
		panel_ispis.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(Color.BLUE, Color.CYAN),
						"Prikaz izabranih domina"));
		add(panel_ispis);
		
		izaberi.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						try
						{
							String unos = unos_a.getText();
							int a = Integer.parseInt(unos);
							unos = unos_b.getText();
							int b = Integer.parseInt(unos);
							izabrana_domina = new Domina(a, b);	
							labela_poruka.setText("");
							if(kolekcija_domina.ukloni(izabrana_domina))
							{	
								// Ponovni ispis kolekcije u konzoli kako bi se videlo da
								// je domina zaista uklonjena
								for(int i=0; i<kolekcija_domina.velicina(); i++)
									System.out.println(kolekcija_domina.vratiDominu(i));
								System.out.println();
								
								izabrano_dugme = new JButton(izabrana_domina.toString());
								izabrano_dugme.setPreferredSize(new Dimension(70, 25));
								panel_ispis.add(izabrano_dugme);
								dugmeta_izbor.add(izabrano_dugme);
								domine_izbor.add(izabrana_domina);
								
								izabrano_dugme.addMouseListener(
										new MouseAdapter() 
										{
											public void mouseEntered(MouseEvent e)
											{
												JButton dugme = (JButton)e.getComponent();
												int index = dugmeta_izbor.indexOf(dugme);
												dugme.setText(
														Integer.toString(domine_izbor.elementAt(index).zbir()));
												dugme.setForeground(Color.MAGENTA);
												
												
											}
											public void mouseExited(MouseEvent e)
											{
												JButton dugme = (JButton)e.getComponent();
												int index = dugmeta_izbor.indexOf(dugme);
												dugme.setText(domine_izbor.elementAt(index).toString());
												dugme.setForeground(Color.BLACK);
											}
											
										}
								);
																					
								brojac++;
															
								if(brojac == za_izbor)
								{
									labela_poruka.setText("Izabran je dovoljan broj domina!");
									unos_a.setEditable(false);
									unos_b.setEditable(false);
								}
							}		
							else
							{
								labela_poruka.setText("Domina je vec izabrana");
							}
							validate();
																			
						}
						catch(NumberFormatException nfe)
						{
							labela_poruka.setText("Domina nije korektno unesena!");
						}
						catch(IllegalArgumentException iae)
						{
							labela_poruka.setText("Domina nije korektno unesena!");
						}
						
											
					}
				}
		);
	
		panel_rezultat = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
		ukupno_tacaka = new JButton("Ukupan broj tacaka");
		polje_rezultat = new JTextField("");
		polje_rezultat.setPreferredSize(new Dimension(70, 25));
		polje_rezultat.setEditable(false);
		panel_rezultat.add(ukupno_tacaka);
		panel_rezultat.add(polje_rezultat);
		
		ukupno_tacaka.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
							int zbir = 0;
							for(Domina domina : domine_izbor)
								zbir += domina.zbir();
							polje_rezultat.setText(Integer.toString(zbir));
						
					}
				}
		);
		
		polje_rezultat.addMouseListener(
			new MouseAdapter()
			{
				private Font stari_font;
				private Color stara_boja;
				
				public void mouseEntered(MouseEvent e)
				{
					stari_font = polje_rezultat.getFont();
					stara_boja = polje_rezultat.getForeground();
					polje_rezultat.setFont(new Font(stari_font.getFamily(), 
							Font.ITALIC, stari_font.getSize() + 10));
					polje_rezultat.setForeground(Color.RED);
				}
				
				public void mouseExited(MouseEvent e)
				{
					polje_rezultat.setFont(stari_font);
					polje_rezultat.setForeground(stara_boja);
					
				}
			}
		);
		
		add(panel_rezultat);
		
	}
	
}
