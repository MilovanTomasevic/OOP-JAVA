package domine;

public class Domina 
{
	private int a;
	private int b;
	
	public Domina(int a, int b) throws IllegalArgumentException
	{
		if(a >= 0 && a <= 6)
			this.a = a;
		else
			throw new IllegalArgumentException("Nekorektna vrednost domine");
		if(b >= 0 && b <= 6)
			this.b = b;
		else
			throw new IllegalArgumentException("Nekorektna vrednost domine");
	}
	
	public int vratiA()
	{
		return a;
	}
	
	public int vratiB()
	{
		return b;
	}
	
	public int zbir()
	{
		return a + b;
	}
	
	public boolean jednake(Domina domina)
	{
		if((a == domina.a && b == domina.b) || (a == domina.b && b == domina.a))
			return true;
		else
			return false;
	}
	
	public String toString()
	{
		return "[" + a + " | " + b + "]";
	}
}
