package paket;


public class Trougao implements Comparable<Trougao>{
	
	private int a,b,c;
	
	//Konstruktor
	public Trougao(int a, int b, int c)
	{
		this.a = a;
		this.b = b;
		this.c = c;		
	}
	
	public int getA(){
		return a;
	}
	
	public int getB(){
		return b;
	}
	
	public int getC(){
		return c;
	}
	
	// Metod za izracunavanje povrsine
	public double povrsina()
	{
		double s =(a+b+c)/2.0;
		return Math.sqrt(s*(s-a)*(s-b)*(s-c));
	}
	
	// Metod za izracunavanje obima
	public int obim()
	{
		return a+b+c;
	}
	
	// Predefinisan metod compareTo()
	public int compareTo(Trougao trougao2)
	{
		double p1 = this.povrsina();
		double p2 = trougao2.povrsina();
		
		// return p1 >= p2 ? 1 : 0;
		if (p1<p2) return -1;
		else if (p1>p2) return 1;
		else return 0;
	}
		
	public static boolean moze(int a, int b, int c){
		return a+b>c && a+c>b && b+c>a && Math.abs(a-b)<c && Math.abs(a-c)<b && Math.abs(c-b)<a;	
	}
	
	// String reprezentacija
	public String toString(){
		return "a = " + a + " b = " + b +" c= " + c + " ( P = " + povrsina() + " )";
	}
	

}
