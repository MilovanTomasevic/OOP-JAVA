package paket;

import java.util.*;

public class Trouglovi {



	//	 Vektor trouglovi
	private Vector<Trougao> trouglovi;
	
	//	 Podrazumevani konstruktor
	public Trouglovi()
	{
		// Kreira se default Vector trouglovi koji ce sadrzati trouglove
		trouglovi = new Vector<Trougao>();
	}
	
	// Konstruktor sa zadatim kapacitetom vektora
	public Trouglovi(int brojTrouglova)
	{
		// Kreira se default Vector objekat koji ce sadrzati trouglove 
		// sa zadatim kapacitetom 
		trouglovi = new Vector<Trougao>(brojTrouglova);
	}
	
	// Dodavanje trougla u vektor
	public boolean dodaj(Trougao novi)
	{
		// Koristimo metod add() klase Vector<>
		return trouglovi.add(novi);
	}
	
	// Vracamo trougao sa zadate pozicije
	public Trougao naPoziciji(int index)
	{
		return trouglovi.get(index);
	}
	
	// Vracamo broj trouglova u vektoru
	public int brojTrouglova()
	{
		return trouglovi.size();
	}
	
	// Vracamo kapacitet vektora
	public int kapacitet()
	{
		return trouglovi.capacity();
	}
	
	// Vracamo iterator kroz vektor
	public Iterator iterator()
	{
		return trouglovi.iterator();
	}
	
	// Metod za sortiranje
	public void sortiraj()
	{
		Collections.sort(trouglovi);
	}
	
	public Trougao poslednji()
	{
		return trouglovi.lastElement();
	}
	

}
