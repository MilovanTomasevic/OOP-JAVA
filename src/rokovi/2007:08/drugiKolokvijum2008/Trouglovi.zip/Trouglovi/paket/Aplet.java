package paket;

import javax.swing.JApplet;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.SwingUtilities;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Dimension;

public class Aplet extends JApplet{

	public void init(){
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				createGUI();
			}
		});	
	}
	
	
	private void createGUI(){
		setSize(300,300);
		setLayout(new GridLayout(8,1));
		
		JPanel panel1=new JPanel(new FlowLayout(FlowLayout.CENTER));
		panel1.add(new JLabel("a:"));
		panel1.add(a=new JTextField());
		a.setPreferredSize(new Dimension(50,25));
		add(panel1);
		
		JPanel panel2=new JPanel(new FlowLayout(FlowLayout.CENTER));
		panel2.add(new JLabel("b:"));
		panel2.add(b=new JTextField());
		b.setPreferredSize(new Dimension(50,25));
		add(panel2);
		
		JPanel panel3=new JPanel(new FlowLayout(FlowLayout.CENTER));
		panel3.add(new JLabel("c:"));
		panel3.add(c=new JTextField());
		c.setPreferredSize(new Dimension(50,25));
		add(panel3);
		
		JPanel panelRDugmad=new JPanel();
		ButtonGroup grupa=new ButtonGroup();
		panelRDugmad.add(obimDugme=new JRadioButton("Obim",true));
		panelRDugmad.add(povrsinaDugme=new JRadioButton("Povrsina",true));
		grupa.add(obimDugme);
		grupa.add(povrsinaDugme);
		obimDugme.setPreferredSize(new Dimension(80,25));
		povrsinaDugme.setPreferredSize(new Dimension(80,25));
		add(panelRDugmad);
		
		JPanel panelObimPovrsina = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelObimPovrsina.add(OP=new JLabel("Obim:"));
		OP.setPreferredSize(new Dimension(60,25));
		panelObimPovrsina.add(OPrez=new JLabel(""));
		OPrez.setPreferredSize(new Dimension(80,25));
		panelObimPovrsina.add(izracunaj=new JButton("Izracunaj"));
		izracunaj.setPreferredSize(new Dimension(100,25));
		add(panelObimPovrsina);
	
		izracunaj.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				int strA;
				try{
					strA=Integer.parseInt(a.getText());
				}catch(NumberFormatException nfe){
					OPrez.setText("a: greska!");
					return;
				}
				int strB;
				try{
					strB=Integer.parseInt(b.getText());
				}catch(NumberFormatException nfe){
					OPrez.setText("b: greska!");
					return;
				}
				int strC;
				try{
					strC=Integer.parseInt(c.getText());
				}catch(NumberFormatException nfe){
					OPrez.setText("c: greska!");
					return;
				}
				
				if(!Trougao.moze(strA,strB,strC)){
					OPrez.setText("Ne moze!");
					return;
				}
				
				Trougao t=new Trougao(strA,strB,strC);
				
				if (obimDugme.isSelected()){
					OP.setText("Obim:");
					OPrez.setText(String.valueOf(t.obim()));
				}else if(povrsinaDugme.isSelected()){
				    OP.setText("Povrsina:");
				    OPrez.setText(String.valueOf(t.povrsina()));
				    
				}
			}
		});
		
		
		
		JPanel panelDodaj=new JPanel(new FlowLayout(FlowLayout.LEFT));
		JLabel l;
		panelDodaj.add(l=new JLabel(""));
		l.setPreferredSize(new Dimension(145,25));
		
		panelDodaj.add(dodaj=new JButton("Dodaj"));
		dodaj.setPreferredSize(new Dimension(100,25));
		
		dodaj.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				int strA;
				try{
					strA=Integer.parseInt(a.getText());
				}catch(NumberFormatException nfe){
					OPrez.setText("a: greska!");
					return;
				}
				int strB;
				try{
					strB=Integer.parseInt(b.getText());
				}catch(NumberFormatException nfe){
					OPrez.setText("b: greska!");
					return;
				}
				int strC;
				try{
					strC=Integer.parseInt(c.getText());
				}catch(NumberFormatException nfe){
					OPrez.setText("c: greska!");
					return;
				}
				
				if(!Trougao.moze(strA,strB,strC)){
					OPrez.setText("Ne moze!");
					return;
				}
				
				trouglovi.dodaj(new Trougao(strA,strB,strC));
				
				
			}
		});
		add(panelDodaj);
		
		
		JPanel panelMaxSortiraj = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelMaxSortiraj.add(max=new JLabel("max:"));
		max.setPreferredSize(new Dimension(60,25));
		panelMaxSortiraj.add(maxrez=new JLabel(""));
		maxrez.setPreferredSize(new Dimension(80,25));
		panelMaxSortiraj.add(sortiraj=new JButton("Sortiraj"));
		sortiraj.setPreferredSize(new Dimension(100,25));
		
		sortiraj.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				trouglovi.sortiraj();
				if(trouglovi.brojTrouglova()>0){
					maxrez.setText(String.valueOf(trouglovi.poslednji().povrsina()));
					
		
					CardHandler ch=new CardHandler();	
					panelRez.removeAll();
					for(int i=0; i<trouglovi.brojTrouglova(); i++){
						Trougao t=trouglovi.naPoziciji(i);
						panelRez.add(dugme=new JButton(t.toString()),"Dugme"+i);
						dugme.addActionListener(ch);
						
					}
				
				}
				else
					maxrez.setText("Nema!");
			}
		});
		add(panelMaxSortiraj);
		
		
		
		add(panelRez);
		panelRez.setLayout(card);
		panelRez.add(dugme=new JButton("Trouglovi"),"Dugme");
	}
	
	
	
	private class CardHandler implements ActionListener{ 
		public void actionPerformed(ActionEvent e){
			card.next(panelRez);
		}
	}
	
	
	
	private JPanel panelRez=new JPanel();
	private CardLayout card=new CardLayout(45,5);
	private JTextField a, b, c;
	private JRadioButton obimDugme, povrsinaDugme;
	private JLabel OP,max;
	private JLabel OPrez, maxrez;
	private JButton izracunaj;
	private JButton dodaj;
	private JButton sortiraj;
	private Trouglovi trouglovi=new Trouglovi();
	private JButton dugme;
}
