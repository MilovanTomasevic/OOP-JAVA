package paket;

import javax.swing.JApplet;
import javax.swing.SwingUtilities;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import javax.swing.ButtonGroup;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MatricaAplet extends JApplet{

	
	public void init(){
		SwingUtilities.invokeLater(
				new Runnable(){
					public void run(){
						createGUI();
					}
				});
	}
	
	public void createGUI(){
		Container content=getContentPane();
		content.setLayout(new GridLayout(3,2,10,10));
		
		
		// Panel koji ce sadrzati text polja za prvu matricu
		JPanel prvaMatrica= new JPanel(new GridLayout(3,3,0,0));
		for(int i=0; i<3; i++)
			for(int j=0; j<3; j++){
				mat1[i][j]=new JTextField();
				prvaMatrica.add(mat1[i][j]);	
			}
		content.add(prvaMatrica);
		
		// Panel koji ce sadrzati text polja za drugu matricu
		JPanel drugaMatrica= new JPanel(new GridLayout(3,3,0,0));
		for(int i=0; i<3; i++)
			for(int j=0; j<3; j++){
				mat2[i][j]=new JTextField();
				drugaMatrica.add(mat2[i][j]);
			}
		content.add(drugaMatrica);
		
		
		content.add(pomnozi=new JButton("Pomnozi"));
		pomnozi.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Matrica A=new Matrica();
				Matrica B=new Matrica();
				for(int i=0; i<3; i++)
					for(int j=0; j<3; j++)try{
						A.setIJ(i, j, Integer.parseInt(mat1[i][j].getText()));
						B.setIJ(i, j, Integer.parseInt(mat2[i][j].getText()));
					}catch(NumberFormatException nfe){
						System.out.println("Neispravan unos");
						System.exit(0);
					}
				Matrica resenje=A.pomnozi(B);
				
				
				Color boja=null;
				for(int i=0; i<boje.length; i++)
					if(boje[i].isSelected()){
						boja=nizColor[i];
						break;
					}
				
				
				
				for(int i=0; i<3; i++)
					for(int j=0; j<3; j++){
						rez[i][j].setText(String.valueOf(resenje.getIJ(i, j)));
						rez[i][j].setForeground(boja);
					}
			}
		});
		
		// Panel koji ce sadrzati text polja za matricu resenje
		JPanel matricaResenje= new JPanel(new GridLayout(3,3,0,0));
		for(int i=0; i<3; i++)
			for(int j=0; j<3; j++){
				rez[i][j]=new JTextField();
				rez[i][j].setEditable(false);
				matricaResenje.add(rez[i][j]);
				
			}
		content.add(matricaResenje);
		
		
		JPanel bojePanel=new JPanel(new GridLayout(0,1));
		bojePanel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED,Color.cyan, Color.blue));
		ButtonGroup group=new ButtonGroup();
		for(int i=0; i<boje.length; i++){
			boje[i]=new JRadioButton(nizBoja[i]);
			boje[i].setForeground(nizColor[i]);
			bojePanel.add(boje[i]);
			group.add(boje[i]);
		}
		boje[0].setSelected(true);
		content.add(bojePanel);
	}
	
	
	
	
	
	private JTextField[][] mat1=new JTextField[3][3];
	private JTextField[][] mat2=new JTextField[3][3];
	private JTextField[][] rez=new JTextField[3][3];
	private JButton pomnozi;
	private JRadioButton[] boje= new JRadioButton[3];
	private static String[] nizBoja={"Plava", "Crvena", "Madjenta"};
	private static Color[] nizColor={Color.blue, Color.red, Color.magenta};
	
}
