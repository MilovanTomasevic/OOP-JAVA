package paket;

public class Matrica {

	public void setIJ(int i, int j, int element){
		mat[i][j]=element;
	}
	
	
	public int getIJ(int i, int j){
		return mat[i][j];
	}
	
	
	public Matrica pomnozi(Matrica A){
		Matrica rez=new Matrica();
		for(int i=0; i<mat.length; i++)
			for(int j=0; j<A.mat[0].length; j++)
				for(int k=0; k<rez.mat.length; k++)
					rez.mat[i][j]+=mat[i][k]*A.mat[k][j];
		return rez;
	}
	
	
	private int[][] mat=new int[3][3];
	
}
