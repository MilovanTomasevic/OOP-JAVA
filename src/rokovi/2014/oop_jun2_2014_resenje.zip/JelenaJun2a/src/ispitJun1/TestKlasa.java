package ispitJun1;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TestKlasa extends Application {

	    // Promenljiva koja ce da cuva referencu na primaryStage
		// kako bismo mogli da ga koristimo u drugim klasama
		public static Stage pomPrimaryStage = null;

		/**
		 * @param args
		 *            the command line arguments
		 */
		public static void main(String[] args) {			
		
			launch(args);
		}

		@Override
		public void start(final Stage primaryStage) throws Exception{
			pomPrimaryStage = primaryStage;
			Parent root = FXMLLoader.load(getClass().getResource("IspistJun1FXML.fxml"));

			Scene scene = new Scene(root);

			primaryStage.setTitle("Veliki celi brojevi");
			primaryStage.setScene(scene);
			primaryStage.show();
		}
}
