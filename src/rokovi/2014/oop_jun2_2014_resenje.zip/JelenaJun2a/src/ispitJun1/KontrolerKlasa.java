package ispitJun1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Vector;





import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.FileChooser;

public class KontrolerKlasa implements Initializable {

	private Vector<VelikiCeoBroj> brojevi = new Vector<VelikiCeoBroj>();

	

	@FXML
	private TextArea textArea = new TextArea();
	
	@FXML
	private Button ucitajBTN = new Button();

		
	@FXML
	private TextField jednocifrenBrojTF = new TextField();
	
	@FXML
	private Button sortirajBTN = new Button();
	
	@FXML
	private Button pomnoziBTN = new Button();
	
	@FXML
	private Button resetujBTN = new Button();

	@FXML
	private void handleButtonUnesi(ActionEvent event) {
		// Ako je program vec pokretan u vectoru ce biti elemenata, 
		// pa hocemo da ih eliminisemo
		
		
		// Kreira se FileChooser
		FileChooser fileChooser = new FileChooser();

		FileChooser.ExtensionFilter extFilter1 = new FileChooser.ExtensionFilter(
				"TXT files (*.txt)", "*.txt");
		fileChooser.getExtensionFilters().add(extFilter1);

		// Postavljamo naziv prozora u kome vrsimo izbor dokumenta
		fileChooser.setTitle("Izaberite dokument");

		String userDirectoryString = System.getProperty("user.home");

		File userDirectory = new File(userDirectoryString);
		if (!userDirectory.canRead()) {
			userDirectory = new File("C:/");
		}
		fileChooser.setInitialDirectory(userDirectory);

		File file = fileChooser.showOpenDialog(TestKlasa.pomPrimaryStage);
		if (file != null) { 
			readFile(file);
			// Ispis svih ucitanih brojeva
			// Ako nisu dobro ucitani brojevi
			// spisuje se poruke Nema brojeva
			if (brojevi.size() == 0)
				textArea.setText("Nema brojeva!");
			else {
				textArea.setText("");
				for (VelikiCeoBroj vcb : brojevi)						
					textArea.appendText(vcb + "\n");
				
			}
		} else
			textArea.setText("Gre�ka!!!\n\nPoku�ajte ponovo...");

	}

	// Metod kojim se ucitava sadrzaj fajla
	public void readFile(File selectedFile) {

		String linija = "";
		VelikiCeoBroj vcb;
		brojevi.clear();

		try {
			FileReader fr = new FileReader(selectedFile);
			BufferedReader br = new BufferedReader(fr);
			while ((linija = br.readLine()) != null) {
				vcb=new VelikiCeoBroj(linija);	
				
				brojevi.add(vcb);
				
			}				
			br.close();
		} catch (Exception e) {
			e.getMessage();
		}
	}
	
	@FXML
	private void handleButtonSortiraj(ActionEvent event) {
		
		if(brojevi.size()!=0)
		{
		
			Collections.sort(brojevi);			
		
		textArea.setText("");
		for (VelikiCeoBroj vcb : brojevi) {
			textArea.appendText(vcb + "\n");
		}
		}
		else textArea.setText("Nema brojeva za sortiranje!");
	}

	
	@FXML
	private void handleButtonResetuj() {
		textArea.setText("");
		
	}
	
	
	@FXML
	private void handleButtonMnoziCifrom() {
		
		String cifraStr = jednocifrenBrojTF.getText();
		
		int broj=Integer.parseInt(cifraStr);
		//ako broj nije jednocifren
		if(broj>=10 || broj<=-10)
			{jednocifrenBrojTF.setText("Broj nije jednocifren!");return;} 
		
		Vector<VelikiCeoBroj> brojeviPomnozeni = new Vector<VelikiCeoBroj>();
		
	
		for (int i=0; i<brojevi.size(); i++) {
			brojeviPomnozeni.add(VelikiCeoBroj.MnozenjeJednocifrenimBrojem(brojevi.get(i), broj));
		}
		textArea.setText("");
		
		brojevi=brojeviPomnozeni;
		
		for (VelikiCeoBroj vcb: brojevi) {
			textArea.appendText(vcb + "\n");
		}
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

	}

}
