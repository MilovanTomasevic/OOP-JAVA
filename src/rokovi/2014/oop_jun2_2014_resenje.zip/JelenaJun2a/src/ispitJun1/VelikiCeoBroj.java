package ispitJun1;

import java.util.Vector;



public class VelikiCeoBroj implements Comparable<VelikiCeoBroj>{
	
	private char Znak;
	private Vector<Integer> Cifre;
	
	public VelikiCeoBroj(){
		Cifre=new Vector<Integer>();
	}
	
	public VelikiCeoBroj(String linija){
		int i=0;
		int j=0;
		if(linija.startsWith("-")){
			Znak='-';
			i++;
			} 
		else Znak='+';
		Cifre= new Vector<Integer>();
		for(; i<linija.length(); i++)
			Cifre.add(j++, linija.charAt(i)-'0');		
	}
	
	public char getZnak(){
		return Znak;
	}
	
	public Vector<Integer> getCifre(){
		return Cifre;
	}
	
	public static VelikiCeoBroj MnozenjeJednocifrenimBrojem(VelikiCeoBroj vcb, int broj){
		
		int prenos = 0;
		char znak = broj>=0? '+' : '-';
		
		//dobijamo apsolutnu vrednost cifre
		if(broj<0) broj=-broj;
		
		VelikiCeoBroj rezultat=new VelikiCeoBroj();
		for( int j=vcb.Cifre.size()-1; j>=0; j--){
		int a = vcb.Cifre.get(j) * broj + prenos;
		rezultat.Cifre.add(0, a % 10);
		prenos = a / 10;
		}
		if(prenos>0)
		rezultat.Cifre.add(0,prenos);
		
		if(vcb.Znak==znak) rezultat.Znak='+';
		else rezultat.Znak='-';
		
		return rezultat;
	}
	
	
	
	public int compareTo(VelikiCeoBroj vcb){
		if(Znak=='-' && vcb.Znak=='+') return -1;
		else if(Znak=='+' && vcb.Znak=='-') return 1;
		else if(Znak=='+') return AbsVeci(this,vcb);
		else return -AbsVeci(this,vcb);
	}
	

	public String toString(){
		String broj="";
		if(Znak=='-')broj+="-";
		for(int i=0; i<Cifre.size(); i++)
			broj+=Cifre.get(i);
		return broj;
	}

private static int AbsVeci(VelikiCeoBroj vcb1, VelikiCeoBroj vcb2){
		
		if(vcb1.Cifre.size()>vcb2.Cifre.size()) return 1;
		if(vcb1.Cifre.size()<vcb2.Cifre.size()) return -1;
		for(int i=0; i<vcb1.Cifre.size(); i++){
			if (vcb1.Cifre.get(i)>vcb2.Cifre.get(i)) return 1;
			if (vcb1.Cifre.get(i)<vcb2.Cifre.get(i)) return -1;
		 }
		
		return 0;
	}	


}
