package JelenaJun2b;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;


public class KontrolerKlasa implements Initializable {		

	@FXML
	private TextField TFbroj1 = new TextField();
	
	@FXML
	private TextField TFbroj2 = new TextField();
	
	@FXML
	private TextField TFrezultat = new TextField();
	
	
	@FXML
	private Button SaberiButton;
	
		
	@FXML
	private void handleButtonSaberi(ActionEvent event) {

		String broj1Str = TFbroj1.getText();
		VelikiCeoBroj vcb1=new VelikiCeoBroj(broj1Str);	
		String broj2Str = TFbroj2.getText();
		VelikiCeoBroj vcb2=new VelikiCeoBroj(broj2Str);	
		VelikiCeoBroj rezultat=VelikiCeoBroj.saberi(vcb1, vcb2);
		TFrezultat.setText(rezultat.toString());
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

	}

}
