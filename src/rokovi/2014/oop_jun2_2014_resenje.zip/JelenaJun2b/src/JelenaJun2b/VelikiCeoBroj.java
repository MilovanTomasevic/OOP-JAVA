package JelenaJun2b;

import java.util.Vector;

public class VelikiCeoBroj{
	
	private char Znak;
	private Vector<Integer> Cifre;
	
	public VelikiCeoBroj(String linija){
		int i=0;
		int j=0;
		if(linija.startsWith("-")) {Znak='-';i++;} else Znak='+';
		Cifre= new Vector<Integer>();
		for(; i<linija.length(); i++)
			Cifre.add(j++, linija.charAt(i)-'0');
		//Okrecemo cifre kako bi na i-toj poziciji u vektoru bila cifra i-te tezine
		for(i=0,j=Cifre.size()-1; i<j; i++,j--){
			int pom;
			pom=Cifre.get(i);
			Cifre.set(i,Cifre.get(j));
			Cifre.set(j,pom);
		}		
	}
	
	public char getZnak(){
		return Znak;
	}
	
	public Vector<Integer> getCifre(){
		return Cifre;
	}
	
		
public static VelikiCeoBroj saberi (VelikiCeoBroj vcb1, VelikiCeoBroj vcb2){
		
		VelikiCeoBroj r=new VelikiCeoBroj("0");
		r.Cifre.clear();
		
		//Ako su brojevi istog znaka
		if( vcb1.Znak == vcb2.Znak){ 
			if(AbsVeci(vcb1,vcb2)>0) r= AbsSabiranje( vcb1, vcb2);
			else
			r= AbsSabiranje( vcb2, vcb1);
			//Rezultat je istog znaka kao i jedan od ova dva broja
			r.Znak = vcb1.Znak;
			}
		//Ako su brojevi razlicitog znaka
		else 
			if( AbsVeci(vcb1, vcb2 )>0){
			r=AbsOduzimanje(vcb1, vcb2);
			r.Znak=vcb1.Znak;
			}		
			else {
			r=AbsOduzimanje( vcb2, vcb1);
			r.Znak = vcb2.Znak;
			}
		return r;
		}
	
	public String toString(){
		String broj="";
		if(Znak=='-')broj+="-";
		for(int i=Cifre.size()-1; i>=0; i--)
			broj+=Cifre.get(i);
		return broj;
	}

private static int AbsVeci(VelikiCeoBroj vcb1, VelikiCeoBroj vcb2){
		
		if(vcb1.Cifre.size()>vcb2.Cifre.size()) return 1;
		if(vcb1.Cifre.size()<vcb2.Cifre.size()) return -1;
		for(int i=0; i<vcb1.Cifre.size(); i++){
			if (vcb1.Cifre.get(i)>vcb2.Cifre.get(i)) return 1;
			if (vcb1.Cifre.get(i)<vcb2.Cifre.get(i)) return -1;
		 }
		
		return 0;
	}	

private static VelikiCeoBroj AbsSabiranje(VelikiCeoBroj veci, VelikiCeoBroj manji){
	
			VelikiCeoBroj r=new VelikiCeoBroj("0");
			r.Cifre.clear();
			int prenos = 0;
			int brCifaraManjeg = manji.Cifre.size();
			int brCifaraVeceg = veci.Cifre.size();
			for( int i=0; i<brCifaraVeceg; i++ ){
			int c =	veci.Cifre.get(i)
			+ ( brCifaraManjeg>i ? manji.Cifre.get(i) : 0 )
			+ prenos;
			if( c>=10 ){
			prenos = 1;
			c -= 10;
			}
			else
			prenos = 0;
			r.Cifre.add(c);
			}
			if( prenos > 0 )
			r.Cifre.add( prenos );
			return r;

	}
	
	private static VelikiCeoBroj AbsOduzimanje(VelikiCeoBroj veci, VelikiCeoBroj manji){
			
		VelikiCeoBroj r=new VelikiCeoBroj("0");
		r.Cifre.clear();
		
		int pozajmica = 0;
		int brCifaraManjeg = manji.Cifre.size();
		int brCifaraVeceg = veci.Cifre.size();
		for( int i=0; i<brCifaraVeceg; i++ ){
		int c =
		(int)veci.Cifre.get(i)
		- (int)( brCifaraManjeg>i ? manji.Cifre.get(i) : 0 )
		- (int)pozajmica;
		if( c<0 ){
		pozajmica = 1;
		c += 10;
		}
		else
		pozajmica = 0;
		r.Cifre.add(c);
		}
		// brisemo vodece nule
		while( r.Cifre.size()>1 && (r.Cifre.lastElement()==0) )
		{			
			r.Cifre.removeElementAt(r.Cifre.size()-1);
			}
		return r;

}
}
