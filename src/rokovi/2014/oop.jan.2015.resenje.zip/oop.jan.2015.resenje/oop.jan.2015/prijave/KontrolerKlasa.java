package prijave;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

public class KontrolerKlasa implements Initializable {
	private List<Prijave> prijave = new ArrayList<Prijave>();

	@FXML
	private Button dugmeBTN, btnIzracunaj;

	@FXML
	private TextArea textArea;

	@FXML
	private TextField textSkolskaGodina;

	private FileChooser fc;
	
	@FXML
	private void handleButtonAction(ActionEvent event) {
		// Ako je program vec pokretan u hashmapi ce biti elemenata,
		// pa hocemo da ih eliminisemo
		prijave.clear();

		File file = fc.showOpenDialog(btnIzracunaj.getScene().getWindow());
		
		if (file != null) {
			// otvara se izabrani fajl za citanje
			try(Scanner sc = new Scanner(file.toPath(), StandardCharsets.UTF_8.name())){
				while(sc.hasNextLine()) {
					String linija = sc.nextLine();
					// 2013: P1, 150, jan1
					String godina = linija.substring(0, linija.indexOf(":")).trim();
					String[] delovi = linija.substring(linija.indexOf(":") + 1,
							linija.length()).split(", ");

					Prijave nova_prijava = new Prijave(godina, delovi[0].trim(),
							Integer.parseInt(delovi[1].trim()), delovi[2].trim());

					// System.out.println(nova_prijava);
					prijave.add(nova_prijava);
				}
					
			} 
			catch (IOException e1) {
				System.out.println(e1.getMessage());
			}
			// Ispis svih ucitanih prijava
			// Ako nisu dobro ucitane - tj. nema navedenih prijava u
			// dokumentu
			// Ispisuje se poruke Nema prijava
			if (prijave.size() == 0)
				textArea.setText("Nema prijava!");
			else {
				textArea.setText("");
				for (Prijave prijava : prijave) {
					textArea.appendText(prijava + "\n");
					// Ucitali smo prijave i ispisali ih u tekst polje
					// ne dozvoljavamo dalje ucitavanje
					// ali dozvoljavamo izracunavanje statistika
					btnIzracunaj.setDisable(false);
					dugmeBTN.setDisable(true);
				}
			}
		} else
			textArea.setText("Pogrešno ste izabrali dokument!!!\n\nPokušajte ponovo...");

	}

	@FXML
	private void handleButtonIzracunaj() {
		List<Par> parovi = new ArrayList<>();
		HashMap<String, Integer> prijaveMap = new HashMap<>();

		for (Prijave p : prijave) {
			//System.out.println(p);
			// Ako nije uneta godina onda radimo za sve
			if (textSkolskaGodina.getText().trim().equals("")) {
				// Ako ne postoji naziv predmeta u HashMapi dodajemo ga
				if (!prijaveMap.containsKey(p.getNaziv_predmeta())) {
					prijaveMap.put(p.getNaziv_predmeta(),
							p.getBr_prijavljenih());
				} else
				// samo sabiramo broj prijavljenih za taj predmet
				{
					int prethodnoPrijavljeni = prijaveMap.get(p
							.getNaziv_predmeta());
					prethodnoPrijavljeni = prethodnoPrijavljeni
							+ p.getBr_prijavljenih();
					prijaveMap.put(p.getNaziv_predmeta(), prethodnoPrijavljeni);
				}
			} else  // inace vrsimo proveru da li je godina 
				// trenutne prijave iz godine koja se trazi
			{
				if (p.getGodina().trim()
						.equals(textSkolskaGodina.getText().trim())) {
					// Ako ne postoji naziv predmeta u HashMapi dodajemo ga
					if (!prijaveMap.containsKey(p.getNaziv_predmeta())) {
						prijaveMap.put(p.getNaziv_predmeta(),
								p.getBr_prijavljenih());
					} else
					// samo sabiramo broj prijavljenih za taj predmet
					{
						int prethodnoPrijavljeni = prijaveMap.get(p
								.getNaziv_predmeta());
						prethodnoPrijavljeni = prethodnoPrijavljeni
								+ p.getBr_prijavljenih();
						prijaveMap.put(p.getNaziv_predmeta(),
								prethodnoPrijavljeni);
					}
				}
			}
			
		}
		// Ako je unet broj u tekst polje, ali nema podataka o prijavama iz te godine
		// ispisujemo poruku
		if (prijaveMap.size() == 0)
		{
			textArea.appendText("------------------------\n");
			textArea.appendText("Nema prijava iz tražene godine!\n");
			textArea.appendText("Pokušajte sa drugom godinom!\n");
				
			textSkolskaGodina.setText("");
		}
					
		textArea.appendText("------------------------\n");

		for (Map.Entry<String, Integer> entry : prijaveMap.entrySet()) {
			parovi.add(new Par(entry.getKey(), entry.getValue()));
		}

		// Ispisujemo opadajuce po broju prijavljenih
		Collections.sort(parovi, new Comparator<Par>() {
			public int compare(Par par1, Par par2) {
				return par2.getVrednost() - par1.getVrednost();
			}
		});

		for (Par par : parovi) {
			textArea.appendText(par.toString() + "\n");
		}

		btnIzracunaj.setDisable(false);

	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// kreiranje FileChooser objekta
		fc = new FileChooser();
		fc.setTitle("Izaberite dokument"); // naslov prozora
		fc.setInitialDirectory(new File(System.getProperty("user.dir")));
				// svaki put kada se otvori prozor,
				// bice prikazan sadrzaj zadatog direktorijuma (ovde: tekuceg) 
				// bez ove linije otvara se sadrzaj direktorijuma u kome je poslednji put izabran fajl
				
		fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter(".txt fajlovi", "*.txt") );
	}

}
