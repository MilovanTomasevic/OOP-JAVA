package prijave;

public class Prijave {
	
	private String naziv_predmeta;
	private String naziv_roka;
	private int br_prijavljenih;
	private String godina;
	
	public Prijave(String godina, String naziv_predmeta, int br_prijavljenih, String naziv_roka) {
		this.naziv_predmeta = naziv_predmeta;
		this.naziv_roka = naziv_roka;
		this.br_prijavljenih = br_prijavljenih;
		this.godina = godina;
	}
	
	public static boolean ispravanNaziv(String naziv) {
		boolean ok = false;
		Rok[] rokovi = Rok.values();
		for(Rok rok : rokovi)
			if(rok.name().equalsIgnoreCase(naziv)){
				ok = true;
				break;
			}
		return ok;		
	}

	@Override
	public String toString() {
		return "naziv_predmeta=" + naziv_predmeta + ", naziv_roka="
				+ naziv_roka + ", br_prijavljenih=" + br_prijavljenih
				+ ", godina=" + godina;
	}
	
	public String getNaziv_predmeta() {
		return naziv_predmeta;
	}

	public void setNaziv_predmeta(String naziv_predmeta) {
		this.naziv_predmeta = naziv_predmeta;
	}

	public int getBr_prijavljenih() {
		return br_prijavljenih;
	}

	public void setBr_prijavljenih(int br_prijavljenih) {
		this.br_prijavljenih = br_prijavljenih;
	}

	public String getGodina() {
		return godina;
	}

	public void setGodina(String godina) {
		this.godina = godina;
	}
	
	
}
