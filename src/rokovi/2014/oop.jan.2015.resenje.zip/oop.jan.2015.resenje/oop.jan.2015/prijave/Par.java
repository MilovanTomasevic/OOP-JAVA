package prijave;
public class Par {
	private String naziv;
	private int vrednost;

	public String getNaziv() {
		return naziv;
	}

	public int getVrednost() {
		return vrednost;
	}

	public Par(String naziv, int vrednost) {
		this.naziv = naziv;
		this.vrednost = vrednost;
	}

	public String toString() {
		return naziv + ": " + vrednost;
	}

}
