package stek;

// enumeracija koja predstavlja skup mogucih
// vrednosti karata
// najslabija karta je DVOJKA, a najjaca KEC
public enum Vrednost {
	DVOJKA, TROJKA, CETVORKA, PETICA, SESTICA, SEDMICA, OSMICA, DEVETKA, DESETKA,
	ZANDAR, DAMA, KRALJ, KEC
}
