package stek;

// enumeracija
// najslabija je boja TREF, pa KARO, onda HERC, i na kraju PIK
public enum Boja {
	TREF, KARO, HERC, PIK
}
