package prijave;

public enum Rok {
	jan1, jan2, jun1, jun2, sep;
}
