package polimorfizamIjosMnogoToga;

/**
 * Klasa ilustruje rad sa objektima izvedenih klasa: <br/>
 * pravljenje objekata <br/>
 * razliku izmedju slucaja kada se u konstruktoru
 * klase Povrs, prilikom inicijalizacije centralne tacke, poziva kopi-konstruktor klase Tacka
 * i slucaja kada se samo uzme referenca na postojecu tacku <br/>
 * pozive metoda opisaniKrug() i dijagonala(), definisanih u klasi Pravougaonik,
 * za objekat tipa Pravougaonik, ali i za objekat tipa Kvadrat, gde predstavljaju nasledjene clanove bazne klase.
 * @author marija
 */
public class TestNasledjivanje {

	public static void main(String[] args) {
		
		// Centralna tacka za krug k
		Tacka centar = new Tacka(0,0);
		System.out.println("Inicijalno centar: " + centar);
		// Pravi se krug sa datom centralnom tackom i poluprecnika 1
		Krug k = new Krug(centar, 1);
		// Ispis String-reprezentacije kruga
		// (implicitno se poziva metod toString())
		System.out.println("k = " + k);
		
		// Izmena tacke koja je ucestvovala u pravljenju centra kruga
		centar.pomeri(10,10); // probati i drugu varijantu konstruktora klase Povrs
		System.out.println();
		// Ispis String-reprezentacije tacke nakon izmene
		System.out.println("Nakon pomeranja: " + centar);
		// Ponovni ispis kruga, kako bismo videli da li se promenila i njegova centralna tacka
		System.out.println("k = " + k);
		System.out.println("PROBATI I SA DRUGOM VARIJANTOM KONSTRUKTORA KLASE Povrs!");
		
		System.out.println();
		
		// Drugi krug
		Krug k2 = new Krug(new Tacka(3,4), 2);
		System.out.println("k2 = " + k2);
		System.out.println("Rastojanje izmedju centara je " + k.rastojanjeDoCentra(k2));

		System.out.println();
		
		Pravougaonik pravougaonik = new Pravougaonik(new Tacka(), 3, 4);
		System.out.println(pravougaonik);
		System.out.println("Opisani " + pravougaonik.opisaniKrug());
		// Poziv metoda dijagonala() kada smo izvan definicije klase Pravougaonik
		// (neophodno koriscenje reference na konkretan objekat, metod nije staticki)
		System.out.println("Duzina dijagonale je: " + pravougaonik.dijagonala());
		System.out.println();
		
		Kvadrat kv = new Kvadrat(new Tacka(3, 4), 2);
		System.out.println("kv = " + kv);
		Kvadrat kopijaKv = new Kvadrat(kv);
		System.out.println("kopijaKv = " + kopijaKv);
		System.out.println("Opisani " + kopijaKv.opisaniKrug());
		System.out.println("Duzina dijagonale je: " + kopijaKv.dijagonala());
	}
}