package polimorfizamIjosMnogoToga;

/**
 * Bazna klasa koja opisuje povrsi u ravni sa centralnom tackom.
 * Iz nje se izvode klase Krug i Pravougaonik, a iz klase  
 * Pravougaonik klasa Kvadrat.
 * 
 * @author marija; biljana
 */
public class Povrs 
{
	/** Povrs je opisana centralnom tackom */
	private Tacka centar;
	
	/** 
	 * Podrazumevani konstruktor:
	 * pravi povrs sa centrom u koordinatnom pocetku
	 */
	public Povrs() 
	{
		centar = new Tacka();
	}
	
	/**
	 * Konstruktor:
	 * pravi povrs sa zadatom centralnom tackom
	 * @param centar centralna tacka povrsi
	 */
	public Povrs(Tacka centar) 
	{
		// prva varijanta: 
		// centar povrsi je nova tacka (kopija postojece)
		// na koju ne ukazuje nijedna spoljasnja referenca
		this.centar = new Tacka(centar);
		
		// druga varijanta:
		// centar povrsi je postojeca tacka
		//this.centar = centar; 
	}
	
	/**
	 * Kopi-konstruktor:
	 * pravi povrs identicnu postojecoj povrsi
	 * @param p postojeca povrs, cija se kopija pravi
	 */
	public Povrs(final Povrs p) 
	{
		this(p.centar);
	}

	/**
	 * Polimorfan metod:
	 * racuna povrsinu povrsi i mora biti definisan i u baznoj klasi 
	 * (upravo ovoj koja se definise)
	 * @return vrednost povrsine povrsi
	 */
	public double povrsina() 
	{
		return 0;
	}

	/**
	 * Polimorfan metod:
	 * pravi novu povrs na osnovu postojece, primenom odgovarajuce
	 * geometrijske transformacije.
	 * @return nova povrs nakon primenjene transformacije
	 */
	public Povrs izvedenaPovrs()
	{
		return new Povrs();
	}

	/**
	 * Vraca centralnu tacku povrsi. 
	 * Nasledjuje se u izvedenim klasama jer je public. 
	 * @return centralna tacka povrsi 
	 */
	public Tacka getCentar() 
	{
		return centar;
	}
	
	/**
	 * Racuna i vraca rastojanje od centra tekuce do 
	 * centra date povrsi p. 
	 * Nasledjuje se u izvedenim klasama, jer je public.
	 * @param p parametar metoda je tipa bazne klase Povrs,
	 * te ce kao stvarni argument moci da se prosledi
	 * referenca na objekat tipa Povrs,
	 * ali i referenca na objekat proizvoljne izvedene klase
	 * (Krug, Pravougaonik, Kvadrat) pri cemu se onda vrsi
	 * implicitno kastovanje navise kroz hijerarhiju klasa
	 * @return rastojanje od centra tekuce do centra date povrsi p
	 */
	public double rastojanjeDoCentra(Povrs p) 
	{
		// poziv metoda rastojanje() iz klase Tacka
		return centar.rastojanje(p.centar);
	}
	
	/** String-reprezentacija povrsi */
	public String toString() 
	{
		return "centar u tacki " + centar;
	}
}
