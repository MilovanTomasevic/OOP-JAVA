package polimorfizamIjosMnogoToga;

/**
 * Класа описује кругове у равни. <br />
 * Изведена је из класе <tt>Povrs</tt>.
 * @author marija; biljana
 */
public class Krug extends Povrs
{
	/** 
	 * Полупречник круга. <br />
	 * Поред свега што има објекат базне класе <tt>Povrs</tt>
	 * (тј. централне тачке),
	 * сваки круг има и свој полупречник.
	 */ 
	private double radius;
	
	/** Конструктор:
	 *  прави круг са задатим центром и полупречником 
	 * 
	 * @param centar централна тачка круга
	 * @param radius полупречник круга
	 */
	public Krug(Tacka centar, double radius) {
		// poziv prvog konstruktora u klasi Povrs
		super(centar);
		this.radius = radius;	
	}
	
	/** Копи-конструктор:
	 *  прави копију постојећег круга. 
	 *
	 * @param k постојећи круг, чију копију правимо
	 */
	public Krug(final Krug k) 
	{
		// Poziv kopi-konstruktora bazne klase
		// ciji je parametar tipa Povrs.
		// Kako je Krug potklasa klase Povrs,
		// kao stvarni argument se moze proslediti
		// i referenca na objekat klase Krug
		// (vrsi se implicitno kastovanje navise).
		super(k);
		//super(k.getCentar()); // alternativa za gornji red
		radius = k.radius;
	}
	
	/** 
	 * Имплементација полиморфног метода, који рачуна површину круга и
 	 * има исти потпис као и метод у базној класи,
	 * исти повратни тип као метод у базној класи,
	 * и исти приступни атрибут као метод у базној класи.
	 * @return површина круга, израчуната по формули: <i>r <sup>2</sup> pi</i>
	 */
	public double povrsina() 
	{
		// PI je staticki clan klase Math iz paketa java.lang.
		// Moze se uvesti naredbom
		// import static java.lang.Math.PI i onda koristiti
		// bez navodjenja imena klase.
		return radius * radius * Math.PI;
	}
	
	/**
	 * Implementacija polimorfnog metoda za generisanje novog kruga 
	 * koji u odnosu na tekuci krug ima:
	 *  - centar simetrican u odnosu na koordinatni pocetak
	 *  - dva puta veci poluprecnik
	 * Metod ima isti potpis kao i metod u baznoj klasi,
	 * povratni tip je Krug (dozvoljeno, jer je Krug potklasa klase Povrs,
	 * a moze i da ostane povratni tip Povrs, kao u baznoj klasi) i
	 * ima isti pristupni atribut kao metod u baznoj klasi.
	 * @return novi krug nakon primenjene transformacije 
	 */
	public Krug izvedenaPovrs()
	{
		return new Krug(new Tacka(
				this.getCentar().getX() == 0 ? 
						this.getCentar().getX() : -this.getCentar().getX(),
				this.getCentar().getY() == 0 ? 
						this.getCentar().getY() : -this.getCentar().getY()),
				this.radius * 2);
	}
	
	/** <tt>String</tt>-репрезентација круга. */
	public String toString() {
		// pomocu super.toString() pozivamo nasledjeni metod toString()
		// bazne klase, cije ime je skriveno istoimenim metodom ove klase
		// te mu se pristupa pomocu kljucne reci super
		return "krug " + super.toString() + " poluprecnik je " + radius;
	}
}
