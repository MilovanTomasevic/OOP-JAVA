package interfejs1;

/**
 * Klasa Povrs:
 *  - implementira interfejs Povrsina
 * Klasa je apstraktna posto ne predefinise apstraktni metod
 * povrsina() nasledjen iz interfejsa Povrsina. 
 */
public abstract class Povrs implements Povrsina {
	/** Povrs je opisana centralnom tackom */
	private Tacka centar;
	
	/** 
	 * Podrazumevani konstruktor:
	 * pravi povrs sa centrom u koordinatnom pocetku
	 */
	public Povrs() {
		centar = new Tacka();
	}
	
	/**
	 * Konstruktor:
	 * pravi povrs sa zadatom centralnom tackom
	 */
	public Povrs(Tacka centar) {
		this.centar = new Tacka(centar);
	}
	
	/**
	 * Kopi-konstruktor:
	 * pravi povrs identicnu postojecoj povrsi
	 */
	public Povrs(final Povrs p) {
		this(p.centar);
	}

	/**
	 * Vraca centralnu tacku povrsi. 
	 * Nasledjuje se u izvedenim klasama jer je public.  
	 */
	public Tacka getCentar() {
		return centar;
	}
	
	/**
     * metod iz interfejsa Povrsina - ne implementira se u klasi
	 * tako da ostaje apstraktan, pa ce i sama klasa biti apstraktna
	 */
	//public abstract double povrsina();
	
	/**
	 * Racuna i vraca rastojanje od centra tekuce do 
	 * centra date povrsi p. 
	 * Nasledjuje se u izvedenim klasama, jer je public.
	 */
	public double rastojanjeDoCentra(Povrs p) {
		// poziv metoda rastojanje() iz klase Tacka
		return centar.rastojanje(p.centar);
	}
	
	/** String-reprezentacija povrsi */
	public String toString() {
		return "centar u tacki " + centar;
	}
}
