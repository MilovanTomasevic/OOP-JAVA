package interfejs1;

/**
 * Klasa opisuje krugove u ravni. 
 * Izvedena je iz klase Povrs. 
 */
public class Krug extends Povrs {
	/** 
	 * Poluprecnik kruga. 
	 * Pored svega sto ima objekat bazne klase Povrs
	 * (tj. centralne tacke), svaki krug
	 * ima i svoj poluprecnik.
	 */ 
	private double radius;
	
	/** 
	 * Konstruktor:
	 * pravi krug sa zadatim centrom i poluprecnikom 
	 */
	public Krug(Tacka centar, double radius) {
		super(centar);
		this.radius = radius;	
	}
	
	/** Kopi konstruktor:
	 *  pravi kopiju postojeceg kruga. 	 
	 */
	public Krug(final Krug k) {
		super(k);
		radius = k.radius;
	}
	
	/** 
	 * Implementacija apstraktnog polimorfnog metoda , koji racuna
	 * povrsinu kruga i ima isti potpis kao i metod u baznoj klasi,
	 * isti povratni tip kao metod u baznoj klasi i isti
	 * pristupni atributi kao metod u baznoj klasi.
	 */
	public double povrsina() {
		return radius * radius * Math.PI;
	}
	
	/** String-reprezentacija kruga. */
	public String toString() {
		return "krug " + super.toString() + " poluprecnik je " + radius;
	}
}
