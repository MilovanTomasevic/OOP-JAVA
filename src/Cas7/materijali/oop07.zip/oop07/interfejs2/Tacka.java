package interfejs2;

/** pomocna klasa, opisuje tacke u ravni (centar povrsi bice objekat ove klase) */

public class Tacka {
	/* Tacka je u 2D odredjena svojom x i y koordinatom */
	
	/** x-koordinata tacke */
	private double x; 
	/** y-koordinata tacke */
	private double y;
						 
	
	/** 
	 * Podrazumevani konstruktor:
	 * pravi tacku u koordinatnom pocetku
	 */
	public Tacka()
	{ }
	
	/** 
	 * Konstruktor: 
	 * pravi tacku od svih neophodnih podataka
	 * (zadate su obe koordinate)
	 */
	public Tacka(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	/** 
	 * Kopi-konstruktor:
	 * pravi tacku identicnu postojecoj 
	 */
	public Tacka(final Tacka t) {
		this(t.x, t.y);
	}
	
	/** 
	 * Racuna i vraca rastojanje od tekuce do zadate tacke 
	 * po poznatoj formuli.
	 */
	public double rastojanje(final Tacka t) {
		return Math.sqrt((x-t.x)*(x-t.x)+(y-t.y)*(y-t.y));
	}
	
	/** 
	 * Pomera tacku za zadate pomeraje po x- i y-osi
	 */
	public void pomeri(double deltaX, double deltaY) {
		x += deltaX;
		y += deltaY;
	}
	
	/** get*() metod za x-koordinatu tacke */
	public double getX() {
		return x;
	}
	
	/** get*() metod za y-koordinatu tacke */
	public double getY() {
		return y;
	}
	
	/** String-reprezentacija tacke */
	public String toString() {
		return "(" + x + ", " + y + ")";
	}
}