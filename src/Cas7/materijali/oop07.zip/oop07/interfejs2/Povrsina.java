package interfejs2;

/** 
 * Interfejs Povrsina:
 * Kroz apstraktni metod povrsina() opisuje se jedna operacija.
 * One klase koje imaju potrebu za definisanjem ovakve operacije
 * implementirace dati interfejs.
 */
public interface Povrsina {

	double povrsina();
}
