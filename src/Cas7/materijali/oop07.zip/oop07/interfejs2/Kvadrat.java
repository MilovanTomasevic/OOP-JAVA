package interfejs2;

/** 
 * Klasa opisuje kvadrate u ravni.
 * Izvedena je iz klase Pravougaonik (koja nasledjuje klasu Povrs).
 */
public class Kvadrat extends Pravougaonik 
{
	// Kvadrat je pravougaonik kod koga je a == b
	// klasa nema dodatnih atributa
	
	/** 
	 * Konstruktor:
	 * pravi kvadrat na osnovu centralne tacke i duzine stranice
	 */
	public Kvadrat(Tacka centar, double a) {
		super(centar, a, a);
	}
	
	/**
	 * Kopi-konstruktor:
	 * pravi kopiju postojeceg kvadrata
	 */
	public Kvadrat(final Kvadrat k) {
		super(k);
	}

	/*
	 * Primetiti da u klasi nema definicije metoda povrsina() niti
	 * dijagonala(), kao ni opisaniKrug().
	 * Svi ti metodi su public u klasi Pravougaonik, pa se nasledjuju u klasi
	 * Kvadrat (mogu da se pozivaju i za objekte ove klase - kvadrate).
	 */
	
	/** String-reprezentacija kvadrata */
	public String toString() {
		return "kvadrat centar u tacki " + getCentar() + " a = " + getA();
	}
}
