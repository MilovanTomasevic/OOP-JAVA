package interfejs2;

import java.util.Random;

public class TestPolimorfizam {

	public static void main(String[] args) {
		// Niz povrsi, da bi elementi bili tipa Krug,
		// Pravougaonik, Kvadrat, niz je tipa bazne klase
		Povrs povrsi[]={new Krug(new Tacka(),1),
				        new Krug(new Tacka(1,1),2),
				        new Pravougaonik(new Tacka(),3,4),
				        new Kvadrat(new Tacka(4,6), 2)};
		
		Random izbor = new Random();
		
		// 5 puta se slucajno bira element niza povrsi
		for(int i=0; i<5; i++)
		{
			// p je promenljiva tipa bazne klase 
			// posto ce se p koristiti za polimorfno pozivanje i metoda obim() (iz interfejsa Obim)
			// i metoda povrsina() (iz interfejsa Povrsina), nijedan od ovih interfejsa se 
			// ne moze zadati kao tip promenljive p.
			Povrs p = povrsi[izbor.nextInt(povrsi.length)];
			System.out.println(p); // Polimorfno se poziva metod toString()
			         
			// Polimorfno pozivanje metoda povrsina()
			System.out.println("Povrsina je " + p.povrsina());
			
			// Polimorfno pozivanje metod obim()
			System.out.println("Obim je " + p.obim());
			
			if(p instanceof Pravougaonik)
				// ako je kastovanje dopusteno (instanceof vratio true)
				// vrsimo kastovanje i pozivamo metod opisaniKrug() definisan u klasi Pravougaonik,
				// koji ne ispunjava uslove za polimorfno pozivanje
				System.out.println("Opisani "+((Pravougaonik)p).opisaniKrug());
			System.out.println();
			
			// public metod getClass() nasledjen iz klase java.lang.Object
			// identifikuje klasu objekta na koji referise promenljiva p.
			// Vraca objekat tipa Class.
			// Metod getName() primenjen nad njim vraca puno kvalifikovano
			// ime klase.
			System.out.println("Tip objekta: " + p.getClass().getName());
			System.out.println();
		}
	}
}
