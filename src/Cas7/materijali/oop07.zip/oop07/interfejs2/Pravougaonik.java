package interfejs2;

/**
 * Klasa opisuje pravougaonike u ravni.
 * Izvedena je iz klase Povrs kao bazne.
 */
public class Pravougaonik extends Povrs 
{
	/*
	 * Pored centralne tacke (bazni deo objekta),
	 * svaki pravougaonik ima jos svoju sirinu i visinu
	 */
	/** sirina pravougaonika */
	private double a;
	/** visina pravougaonika */
	private double b;
	
	/**
	 * Konstrktor:
	 * pravi pravougaonik na osnovu datog centra, sirine i visine
	 */
	public Pravougaonik(Tacka centar, double a, double b) {
		super(centar);
		this.a = a;
		this.b = b;
	}
	
	/** 
	 * Kopi-konstruktor:
	 * pravi identicnu kopiju postojeceg pravougaonika
	 */
	public Pravougaonik(final Pravougaonik p) {
		super(p);
		a = p.a;
		b = p.b;
	}
	
	/** 
	 * Racunanje dijagonale tekuceg pravougaonika
	 * kao duzine hipotenuze pravouglog trougla
	 * sa katetama jednakim sirini i visini pravougaonika
	 */	
	public double dijagonala() {
		return Math.sqrt(a*a + b*b);
	}
	
	/** 
	 * Pravi i vraca krug opisan oko tekuceg pravougaonika
	 */
	public Krug opisaniKrug() {
		return new Krug(getCentar(), 0.5*dijagonala());
	}
	
	/** Implementacija apstraktnog metoda iz interfejsa Povrsina 
	 *  racunanje povrsine tekuceg pravougaonika */
	public double povrsina() {
		return a*b;
	}
	
	/** implementacija metoda iz interfejsa Obim
	 *  racunanje obima tekuceg pravougaonika */
	public double obim() {
		return 2*(a+b);
	}

	/** 
	 * Vraca duzinu stranice a; bice nasledjen u izvedenoj klasi Kvadrat
	 * @return duzina stranice a
	 */
	public double getA() {
		return a;
	}
	
	/** String-reprezentacija pravougaonika */
	public String toString() {
		return "pravougaonik " + super.toString() + " a = " + a + " b = " + b;
	}
}
