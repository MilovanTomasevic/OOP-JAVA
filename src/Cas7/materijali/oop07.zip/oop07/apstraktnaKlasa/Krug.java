package apstraktnaKlasa;

/**
 * Класа описује кругове у равни. <br/>
 * Изведена је из класе <tt>Povrs</tt>.
 * @author marija; biljana
 */
/* NAPOMENA: Kodiranje je moguce podesiti tako da se mogu
 * unositi nasa cirilicna ili latinicna slova u 
 * dokumentacionim komentarima:
 * Widnow -> Preferences -> (prosiriti) General -> Workspace
 * U delu Text file encoding selektovati Other: i iz padajuce
 * liste izabrati UTF-8.
 * Dokumentacioni komentari mogu da sadrze i html elemente 
 * za oznacavanje delova teksta. 
 */
public class Krug extends Povrs {
	/** 
	 * Полупречник круга. <br/>
	 * Поред свега што има објекат базне класе <tt>Povrs</tt>
	 * (тј. централне тачке),
	 * сваки круг има и свој полупречник.
	 */ 
	private double radius;
	
	/** Конструктор:
	 *  прави круг са задатим центром и полупречником 
	 * 
	 * @param centar централна тачка круга
	 * @param radius полупречник круга
	 */
	public Krug(Tacka centar, double radius) {
		super(centar);
		this.radius = radius;	
	}
	
	/** Копи-конструктор:
	 *  прави копију постојећег круга. 
	 *
	 * @param k постојећи круг, чију копију правимо
	 */
	public Krug(final Krug k) {
		super(k);
		radius = k.radius;
	}
	
	/** 
	 * Имплементација апстрактног полиморфног метода, који рачуна 
	 * површину круга и има исти потпис као и метод у базној класи,
	 * исти повратни тип као метод у базној класи
	 * и исти приступни атрибут као метод у базној класи.
	 * @return површина круга, израчуната по формули: <i>r <sup>2</sup> pi</i>
	 */
	public double povrsina() {
		return radius * radius * Math.PI;
	}
	
	/**
	 * Implementacija apstraktnog polimorfnog metoda za pravljenje 
	 * novog kruga koji u odnosu na tekuci krug ima:
	 *  - centar simetrican u odnosu na koordinatni pocetak
	 *  - dva puta veci poluprecnik
	 * Metod ima isti potpis kao i metod u baznoj klasi,
	 * povratni tip je Krug (dozvoljeno, jer je Krug potklasa klase Povrs,
	 * a moze i da ostane povratni tip Povrs, kao u baznoj klasi) i
	 * ima isti pristupni atribut kao metod u baznoj klasi.
	 * @return novi krug nakon primenjene transformacije 
	 */
	public Krug izvedenaPovrs()
	{
		return new Krug(new Tacka(
				this.getCentar().getX() == 0 ? 
						this.getCentar().getX() : -this.getCentar().getX(),
				this.getCentar().getY() == 0 ? 
						this.getCentar().getY() : -this.getCentar().getY()),
				this.radius * 2);
	}
	
	/** <tt>String</tt>-репрезентација круга. */
	public String toString() {
		return "krug " + super.toString() + " poluprecnik je " + radius;
	}
}
