package apstraktnaKlasa;

import java.util.Random;

/** 
 * Pored polimorfnog pozivanja metoda povrsina(), izvedenaPovrs() i toString()
 * ilustruje se i generisanje slucajnih celih brojeva
 * iz opsega [0,n-1],
 * kao i izbor slucajnog elementa niza
 * <br/>
 * Izbor metoda izvedene klase, koji se polimorfno izvrsava, vrsi se dinamicki, u vreme izvrsavanja programa,
 * a ne u vreme njegovog prevodjenja i to na osnovu tipa objekta za koji je metod pozvan,
 * a ne na osnovu tipa promenljive koja cuva referencu na taj objekat.
 * Kako se elementi niza slucajno biraju u vreme izvrsavanja programa, 
 * ne moze se unapred znati kog tipa ce biti objekat na koji se cuva referenca u
 * promenljivoj "p" prilikom poziva polimorfnih metoda.
 *
 * @author marija i biljana
 */
public class TestPolimorfizam {

	public static void main(String[] args) {
		// Niz povrsi, da bi elementi bili tipa Krug,
		// Pravougaonik, Kvadrat, niz je tipa bazne klase
		Povrs povrsi[]={new Krug(new Tacka(),1),
				        new Krug(new Tacka(1,1),2),
				        new Pravougaonik(new Tacka(),3,4),
				        new Kvadrat(new Tacka(4,6), 2)};
		
		// Objekat klase Random iz paketa java.util
		// predstavlja generator pseudoslucajnih brojeva
		Random izbor = new Random();
				
		// 5 puta se slucajno bira element niza povrsi
		for(int i=0; i<5; i++)
		{
			// p je promenljiva tipa bazne klase koja cuva
			// referencu na objekat izvedene (jedan od uslova za polimorfizam)
			// izbor.nextInt(n) vraca slucajan ceo broj iz opsega [0,...,n-1]
			// sto je validan indeks niza koji ima n elemenata
			
			// Dozvoljeno je da se deklarise promenljiva tipa apstraktne
			// klase, ali nije dozvoljeno praviti objekte apstraktne klase.
			
			// Da bismo slucajno izabrali element niza povrsi,
			// nadjemo slucajan indeks za taj niz:
			// izbor.nextInt(povrsi.length)
			// a indeksiranjem niza tim indeksom dobijamo slucajan element niza:
			Povrs p = povrsi[izbor.nextInt(povrsi.length)];
			System.out.println(p); // Polimorfno se poziva metod toString()
			         // koji takodje ispunjava uslove za polimorfizam
			// Polimorfno pozivanje metoda povrsina()
			System.out.println("Povrsina je " + p.povrsina());
			// Polimorfno pozivanje metoda za generisanje nove povrsi 
			System.out.println("Nova povrs nakon transformacije: " + p.izvedenaPovrs());
			// Pomocu promenljive tipa bazne klase moguce je pozivati
			// samo polimorfne metode, ne i metode izvedenih klasa
			// koji ne ispunjavaju uslov za polimorfizam.
			// Za njihovo pozivanje neophodno je izvrsiti kastovanje nanize
			// u tip klase u kojoj je definisan metod koji se zeli pozvati.
			
			// Kastovanje nanize kroz hijerarhiju klasa:
			// provera da li je dopusteno kastovati tip objekta na koji ukazuje referenca p 
			// u tip Pravougaonik
			// (a s obzirom na to kako izgleda hijerarhija klasa,
			//  dopusteno je ako je u p referenca na objekat klase Pravougaonik ili Kvadrat
			// (instanceof vraca true ako je u p referenca na objekat koji je tipa Pravougaonik
			//  ili njegove proizvoljne potklase)
			
			if(p instanceof Pravougaonik)
			// if(p.getClass() == Pravougaonik.class)
				// ako je kastovanje dopusteno (instanceof vratio true)
				// vrsimo kastovanje i pozivamo metod opisaniKrug() definisan u klasi Pravougaonik,
				// koji ne ispunjava uslove za polimorfno pozivanje
				System.out.println("Opisani "+((Pravougaonik)p).opisaniKrug());
			System.out.println();
			
			// public metod getClass() nasledjen iz klase java.lang.Object
			// identifikuje klasu objekta na koji referise promenljiva p.
			// Vraca objekat tipa Class.
			// Metod getName() primenjen nad njim vraca puno kvalifikovano
			// ime klase.
			System.out.println("Tip objekta: " + p.getClass().getName());
			System.out.println();
		}
		
		//System.out.println(String.class);
	}
}