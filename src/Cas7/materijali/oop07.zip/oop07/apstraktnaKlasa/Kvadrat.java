package apstraktnaKlasa;

/** 
 * Klasa opisuje kvadrate u ravni.
 * Izvedena je iz klase Pravougaonik (koja nasledjuje klasu Povrs).
 * @author marija; biljana
 */
public class Kvadrat extends Pravougaonik {
	// Kvadrat je pravougaonik kod koga je a == b
	// klasa nema dodatnih atributa
	
	/** 
	 * Konstruktor:
	 * pravi kvadrat na osnovu centralne tacke i duzine stranice
	 *
	 * @param centar centralna tacka kvadrata
	 * @param a duzina stranice kvadrata
	 */
	public Kvadrat(Tacka centar, double a) {
		super(centar, a, a);
	}
	
	/**
	 * Kopi-konstruktor:
	 * pravi kopiju postojeceg kvadrata
	 * @param k postojeci kvadrat, ciju kopiju pravimo
	 */
	public Kvadrat(final Kvadrat k) {
		super(k);
	}

	/*
	 * Primetiti da u klasi nema definicije metoda povrsina() niti
	 * dijagonala(), kao ni opisaniKrug().
	 * Svi ti metodi su public u klasi Pravougaonik, pa se nasledjuju u klasi
	 * Kvadrat (mogu da se pozivaju i za objekte ove klase - kvadrate).
	 */
	
	/**
	 * Predefinisanje polimorfnog metoda za pravljenje novog kvadrata 
	 * koji u odnosu na tekuci kvadrat ima:
	 *  - centar simetrican u odnosu na koordinatni pocetak
	 *  - stranicu jednaku dijagonali tekuceg kvadrata
	 * Metod ima isti potpis kao i metod u baznoj klasi,
	 * povratni tip je Kvadrat (dozvoljeno, jer je Kvadrat potklasa klase Pravougaonik,
	 * a moze da ostane i Pravougaonik kao u baznik klasa) i
	 * ima isti pristupni atribut kao metod u baznoj klasi.
	 * @return novi kvadrat nakon primenjene transformacije 
	 */
	public Kvadrat izvedenaPovrs() {
		return new Kvadrat(new Tacka(
				this.getCentar().getX() == 0 ? 
						this.getCentar().getX() : -this.getCentar().getX(),
				this.getCentar().getY() == 0 ? 
						this.getCentar().getY() : -this.getCentar().getY()),
				this.dijagonala());
	}

	/** String-reprezentacija kvadrata */
	public String toString() {
		return "kvadrat centar u tacki " + getCentar() + " a = " + getA();
	}
}
