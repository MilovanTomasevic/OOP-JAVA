package apstraktnaKlasa;

/**
 * Klasa opisuje pravougaonike u ravni.
 * Izvedena je iz klase Povrs kao bazne.
 * @author marija; biljana
 */
public class Pravougaonik extends Povrs {
	/* Pored centralne tacke (bazni deo objekta),
	 * svaki pravougaonik ima jos svoju sirinu i visinu
	 */
	/** sirina pravougaonika */
	private double a;
	/** visina pravougaonika */
	private double b;
	
	/**
	 * Konstrktor:
	 * pravi pravougaonik na osnovu datog centra, sirine i visine
	 * @param centar centralna tacka pravougaonika
	 * @param a sirina pravougaonika
	 * @param b visina pravougaonika
	 */
	public Pravougaonik(Tacka centar, double a, double b) {
		super(centar);
		this.a = a;
		this.b = b;
	}
	
	/** 
	 * Kopi-konstruktor:
	 * pravi identicnu kopiju postojeceg pravougaonika
	 * @param p postojeci pravougaonik, cija se kopija pravi
	 */
	public Pravougaonik(final Pravougaonik p) {
		super(p);
		a = p.a;
		b = p.b;
	}
	
	/** 
	 * Racunanje dijagonale tekuceg pravougaonika
	 * kao duzine hipotenuze pravouglog trougla
	 * sa katetama jednakim sirini i visini pravougaonika
	 * @return duzina dijagonale tekuceg pravougaonika
	 */	
	public double dijagonala() {
		return Math.sqrt(a*a + b*b);
	}
	
	/** 
	 * Pravi i vraca krug opisan oko tekuceg pravougaonika
	 * @return krug opisan oko tekuceg pravougaonika
	 */
	public Krug opisaniKrug() {
		return new Krug(getCentar(), 0.5*dijagonala());
	}
	
	/** 
	 * Implementacija apstraktnog polimorfnog metoda
	 * za racunanje povrsine tekuceg pravougaonika.
	 * Metod ima isti potpis, isti povratni tip
	 * i isti pristupni atribut kao i u baznoj klasi.
	 * @return povrsina tekuceg pravougaonika izracunata po formuli: P = a*b
	 */
	public double povrsina() {
		return a*b;
	}
	
	/**
	 * Implementacija apstraktnog polimorfnog metoda za pravljenje novog pravougaonika 
	 * koji u odnosu na tekuci pravougaonik ima:
	 *  - centar simetrican u odnosu na koordinatni pocetak
	 *  - sirinu jednaku visini tekuceg pravougaonika
	 *  - visinu jednaku sirini tekuceg pravougaonika
	 * Metod ima isti potpis kao i metod u baznoj klasi,
	 * povratni tip je Pravougaonik (dozvoljeno, jer je Pravougaonik potklasa klase Povrs,
	 * a moze i da ostane povratni tip Povrs, kao u baznoj klasi) i
	 * ima isti pristupni atribut kao metod u baznoj klasi.
	 * @return novi pravougaonik nakon primenjene transformacije 
	 */
	public Pravougaonik izvedenaPovrs()
	{
		return new Pravougaonik(new Tacka(
				this.getCentar().getX() == 0 ? 
						this.getCentar().getX() : -this.getCentar().getX(),
				this.getCentar().getY() == 0 ? 
						this.getCentar().getY() : -this.getCentar().getY()),
				b, a);
	}

	/** 
	 * Vraca duzinu stranice a; bice nasledjen u izvedenoj klasi Kvadrat
	 * @return duzina stranice a
	 */
	public double getA() {
		return a;
	}
	
	/** String-reprezentacija pravougaonika */
	public String toString() {
		return "pravougaonik " + super.toString() + " a = " + a + " b = " + b;
	}
}
