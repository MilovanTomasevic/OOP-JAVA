package apstraktnaKlasa;

/**
 * Bazna klasa Povrs definisana kao apstraktna klasa 
 * (abstract class).
 * Polimorfan metod povrsina() definisan je kao apstraktni metod, 
 * sto znaci da se navodi samo prototip metoda uz dodatu 
 * kljucnu rec abstract.
 * Cim klasa ima bar jedan apstraktni metod i sama mora biti apstrakta.
 * NAPOMENA: apstraktna klasa ne moze da se instancira,
 * tj. nije moguce praviti objekte ovakve klase!!!
 * Apstraktni metod ne sme biti private, jer nece
 * biti nasledjen, pa samim tim se ne moze predefinisati
 * u izvedenim klasama!!!
 * 
 * Ujedno je ilustrovana upotreba dokumentacionih komentara. 
 */
public abstract class  Povrs {
	/** Povrs je opisana centralnom tackom */
	private Tacka centar;
	
	/** 
	 * Podrazumevani konstruktor:
	 * pravi povrs sa centrom u koordinatnom pocetku
	 */
	public Povrs() {
		centar = new Tacka();
	}
	
	/**
	 * Konstruktor:
	 * pravi povrs sa zadatom centralnom tackom
	 * @param centar centralna tacka povrsi
	 */
	public Povrs(Tacka centar) {
		this.centar = new Tacka(centar);
	}
	
	/**
	 * Kopi-konstruktor:
	 * pravi povrs identicnu postojecoj povrsi
	 * @param p postojeca povrs, cija se kopija pravi
	 */
	public Povrs(final Povrs p) {
		this(p.centar);
	}

	/**
	 * Apstraktan polimorfan metod
	 * u opstem slucaju, za povrs ne znamo da definisemo
	 * kako se racuna povrsina
	 * @return vrednosti povrsine povrsi
	 */
	public abstract double povrsina();
	
	/**
	 * Apstraktan polimorfan metod:
	 * pravi novu povrs na osnovu postojece primenom transformacije
	 * @return nova povrs nakon primenjene transformacije
	 */
	public abstract Povrs izvedenaPovrs();
	
	/**
	 * Vraca centralnu tacku povrsi. 
	 * Nasledjuje se u izvedenim klasama jer je public.  
	 */
	public Tacka getCentar() {
		return centar;
	}
	
	/**
	 * Racuna i vraca rastojanje od centra tekuce do 
	 * centra date povrsi p. 
	 * Nasledjuje se u izvedenim klasama, jer je public.
	 * @param p parametar metoda je tipa bazne klase Povrs,
	 * te ce kao stvarni argument moci da se prosledi
	 * referenca na objekat tipa Povrs,
	 * ali i referenca na objekat proizvoljne izvedene klase
	 * (Krug, Pravougaonik, Kvadrat) pri cemu se onda vrsi
	 * implicitno kastovanje navise kroz hijerarhiju klasa
	 * @return rastojanje od centra tekuce do centra date povrsi p
	 */
	public double rastojanjeDoCentra(Povrs p) {
		// poziv metoda rastojanje() iz klase Tacka
		return centar.rastojanje(p.centar);
	}
	
	/** String-reprezentacija povrsi */
	public String toString() {
		return "centar u tacki " + centar;
	}
}
