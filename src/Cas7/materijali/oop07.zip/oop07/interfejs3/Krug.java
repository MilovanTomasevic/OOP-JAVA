package interfejs3;

/**
 * Klasa opisuje krugove u ravni. 
 */
public class Krug implements Povrsina, Obim, Opisivanje
{
	/** 
	 * Pored centralne tacke, svaki krug ima i svoj poluprecnik */ 
	private Tacka centar;
	private double radius;
	
	/** Konstruktor:
	 *  pravi krug sa zadatim centrom i poluprecnikom 
	 */
	public Krug(Tacka centar, double radius) {
		this.centar = new Tacka(centar);
		this.radius = radius;
	}
	
	/** Kopi konstruktor:
	 *  pravi kopiju postojeceg kruga. 	 
	 */
	public Krug(final Krug k) {
		this(k.centar, k.radius);
	}
	
	/** implementacija metoda iz interfejsa Povrsina
     *  racunanje povrsine tekuceg kruga */
	public double povrsina() {
		return radius * radius * Math.PI;
	}
		
	/** implementacija metoda iz interfejsa Obim
	 *  racunanje obima tekuceg kruga */
	public double obim() {
		return 2 * radius * Math.PI;
	}
		
	/** implementacija metoda iz interfejsa Opisivanje
	 *  povratni tip je Kvadrat */
	public Kvadrat opisi() {
		// kvadrat opisan oko kruga ima isti centar
		// i stranicu dva puta duzu od poluprecnika kruga
		return new Kvadrat(centar, 2*radius);
	}
	
	/** implementacija preostalih metoda iz interfejsa Opisivanje */
	
	public double rastojanjeDoCentra(Opisivanje p) {
		return centar.rastojanje(p.getCentar());
	}
	
	public Tacka getCentar() {
		return centar;
	}
	
	/** String-reprezentacija kruga. */
	public String toString() {
		return "krug: centar u tacki " + centar + " poluprecnik je " + radius;
	}
}
