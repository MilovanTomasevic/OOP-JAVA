package interfejs3;

/** 
 * Interfejs Obim:
 * Sadrzi apstraktan metod za racunanje obima povrsi. 
 *
 */
public interface Obim {
	
	double obim();
}
