package interfejs3;

/**
 * Klasa opisuje pravougaonike u ravni.
 */
public class Pravougaonik implements Povrsina, Obim, Opisivanje {
	/*
	 * Pored centralne tacke,
	 * svaki pravougaonik ima jos svoju sirinu i visinu
	 */
	/** centralna tacka pravougaonika */
	private Tacka centar;
	/** sirina pravougaonika */
	private double a;
	/** visina pravougaonika */
	private double b;
	
	/**
	 * Konstrktor:
	 * pravi pravougaonik na osnovu datog centra, sirine i visine
	 */
	public Pravougaonik(Tacka centar, double a, double b) {
		this.centar = new Tacka(centar);
		this.a = a;
		this.b = b;
	}
	
	/** 
	 * Kopi-konstruktor:
	 * pravi identicnu kopiju postojeceg pravougaonika
	 */
	public Pravougaonik(final Pravougaonik p) {
		this(p.centar, p.a, p.b);
	}
	
	/** 
	 * Racunanje dijagonale tekuceg pravougaonika
	 * kao duzine hipotenuze pravouglog trougla
	 * sa katetama jednakim sirini i visini pravougaonika
	 */	
	public double dijagonala() {
		return Math.sqrt(a*a + b*b);
	}
	
	/** 
	 * Pravi i vraca krug opisan oko tekuceg pravougaonika
	 */
	public Krug opisaniKrug() {
		return new Krug(centar, 0.5*dijagonala());
	}
	
	/** Implementacija apstraktnog metoda iz interfejsa Povrsina 
	 *  racunanje povrsine tekuceg pravougaonika */
	public double povrsina() {
		return a*b;
	}
	
	/** implementacija metoda iz interfejsa Obim
	 *  racunanje obima tekuceg pravougaonika */
	public double obim() {
		return 2*(a+b);
	}
	
	/** implementacija metoda iz interfejsa Opisivanje
	 *  poziva prethodno definisani metod opisaniKrug() */
	public Krug opisi() {
		return opisaniKrug();
	}
	
	/** implementacija preostalih metoda iz interfejsa Opisivanje */
	
	public double rastojanjeDoCentra(Opisivanje p) {
		return centar.rastojanje(p.getCentar());
	}
	
	/** Vraca centralnu tacku pravougaonika; bice nasledjen u izvedenoj klasi Kvadrat */
	public Tacka getCentar() {
		return centar;
	}
	
	/** Vraca duzinu stranice a; bice nasledjen u izvedenoj klasi Kvadrat */
	public double getA() {
		return a;
	}
	
	/** String-reprezentacija pravougaonika */
	public String toString() {
		return "pravougaonik: centar u tacki " + centar + " a = " + a + " b = " + b;
	}
}
