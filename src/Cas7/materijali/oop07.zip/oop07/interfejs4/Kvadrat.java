package interfejs4;

public class Kvadrat extends Pravougaonik {
	
	// Kvadrat je pravougaonik kod koga je a == b
	// klasa nema dodatnih atributa
	
	// konstruktor kreira kvadrat na osnovu svih
	// neophodnih podataka
	public Kvadrat(Tacka centar, double a) {
		super(centar, a, a);
	}
	
	// String-reprezentacija kvadrata
	public String toString() {
		return "kvadrat: centar u tacki " + getCentar() + " a = " + getA();
	}
}
