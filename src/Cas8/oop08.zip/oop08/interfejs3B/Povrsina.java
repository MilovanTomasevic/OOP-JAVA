package interfejs3B;

public interface Povrsina {
	
	double povrsina();
}
