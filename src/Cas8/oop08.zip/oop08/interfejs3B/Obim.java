package interfejs3B;

public interface Obim {
	
	double obim();
}
