package interfejs2;

/** 
 * Interfejs Obim:
 * Kroz apstraktni metod obim() opisuje se operacija racunanja
 * obima povrsi. One klase koje imaju potrebu za definisanjem 
 * ovakve operacije implementirace dati interfejs.
 */
public interface Obim {
	
	double obim();
}
