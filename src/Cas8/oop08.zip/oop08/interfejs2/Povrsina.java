package interfejs2;

public interface Povrsina {

	double povrsina();
}
