package interfejs3A;

public interface Povrsina {
	
	double povrsina();
}
