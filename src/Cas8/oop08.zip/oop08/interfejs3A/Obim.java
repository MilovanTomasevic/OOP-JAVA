package interfejs3A;

public interface Obim {
	
	double obim();
}
