package interfejs4;

public interface Translacija {

	void pomeri(double deltaX, double deltaY);
}
