package primer04StudentMinimalnoEnkapsulacija;

/**
 * Dodatak:
 * - enkapsulacija: polja su private
 */
public class Student {
    private String ime; // ime studenta
    private String prezime; // prezime studenta
    private String indeks; // indeks studenta
    // implicitno se inicijalizuju na null

    private double prosek; // prosek studenta; implicitno se inicijalizuje na 0.0

    // obezbedjeni podrazumevani konstruktor i metod toString()

}

