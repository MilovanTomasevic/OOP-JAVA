package primeri;

public class Primer01 {

	/**
	 * Jednostavan program koji ispisuje 'Zdravo svete!'.
	 * Uvek ovo prvo pisati pri ucenju novog jezika kako bi se postovala
	 * visegodisnja programerska tradicija!
	 */
	public static void main(String[] args) {
		System.out.println("Zdravo svete!");
	}
}
